// Define o pacote Controller, que organiza as classes do projeto.
package Controller;

// Importa as classes e bibliotecas utilizadas neste arquivo.
import Model.Campeonato;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

// Classe responsável por controlar as ações relacionadas a campeonato.
public class CampeonatoController {
    // Atributos
    private static final CampeonatoController instancia = new CampeonatoController();

    // Atributo utilizado para armazenar campeonatos.
    private final ArrayList<Campeonato> campeonatos;

    // Construtores
    private CampeonatoController() {
        campeonatos = new ArrayList<>();
        carregarDadosDemonstrativos();
    }

    // Método utilizado para consultar instancia.
    public static CampeonatoController getInstancia() {
        return instancia;
    }

    // Dados demonstrativos
    private void carregarDadosDemonstrativos() {
        campeonatos.add(new Campeonato(
                "Copa Universitária de Futsal",
                "Futsal",
                "Competição universitária entre equipes participantes.",
                "Calendário a definir",
                "Planejado"
        ));

        campeonatos.add(new Campeonato(
                "Torneio Universitário de Voleibol",
                "Voleibol",
                "Torneio de integração e competição entre equipes.",
                "Calendário a definir",
                "Planejado"
        ));

        campeonatos.add(new Campeonato(
                "Campeonato de Basquetebol",
                "Basquetebol",
                "Competição universitária de basquetebol.",
                "Calendário a definir",
                "Planejado"
        ));

        campeonatos.add(new Campeonato(
                "Jogos Universitários",
                "Multiesportivo",
                "Evento esportivo universitário com diferentes modalidades.",
                "Calendário a definir",
                "Planejado"
        ));

        campeonatos.add(new Campeonato(
                "Festival de Atletismo",
                "Atletismo",
                "Evento demonstrativo de competições de atletismo.",
                "Calendário a definir",
                "Planejado"
        ));
    }

    // Método utilizado para consultar listar todos.
    public List<Campeonato> listarTodos() {
        return new ArrayList<>(campeonatos);
    }

    // Método responsável por filtrar.
    public List<Campeonato> filtrar(String pesquisa, String status) {
        String termo = pesquisa == null ? "" : pesquisa.trim().toLowerCase(Locale.ROOT);

        return campeonatos.stream().filter(campeonato -> {
                    boolean correspondePesquisa = campeonato.getNome().toLowerCase(Locale.ROOT).contains(termo) || campeonato.getModalidade().toLowerCase(Locale.ROOT).contains(termo) || campeonato.getDescricao().toLowerCase(Locale.ROOT).contains(termo);

                    boolean correspondeStatus = status == null || status.equals("Todos") || campeonato.getStatus().equals(status);

                    return correspondePesquisa && correspondeStatus;
                }).toList();
    }
}
