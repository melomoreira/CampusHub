// Define o pacote Controller, que organiza as classes do projeto.
package Controller;

// Importa as classes e bibliotecas utilizadas neste arquivo.
import Model.MaterialEstudo;
import Model.MaterialEstudo.Tipo;
import Model.Usuario;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;

import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;

import javafx.stage.Stage;

import javafx.util.StringConverter;

import java.awt.Desktop;
import java.net.URI;

import java.time.format.DateTimeFormatter;

import java.io.IOException;
import java.util.List;

// Classe responsável por controlar as ações relacionadas a tela materiais.
public class TelaMateriaisController {
    // Atributos
    @FXML private TextField campoBusca;
    @FXML private TextField filtroDisciplina;
    @FXML private ComboBox<Tipo> filtroTipo;

    @FXML private TextField campoTitulo;
    @FXML private TextField campoDisciplina;
    @FXML private ComboBox<Tipo> campoTipoMaterial;
    @FXML private TextArea campoDescricao;
    @FXML private TextField campoLink;

    @FXML private Button botaoSalvar;
    @FXML private Button botaoCancelar;

    @FXML private VBox listaMateriais;
    @FXML private Label labelQuantidade;

    private final MaterialEstudoController controller = MaterialEstudoController.getInstancia();

    // Atributo utilizado para armazenar id em edicao.
    private String idEmEdicao = null;

    private final DateTimeFormatter formatoData = DateTimeFormatter.ofPattern("dd/MM/yyyy 'às' HH:mm");

    @FXML
    private void initialize() {
        configurarTipos();

        atualizarLista();
    }

    // Método responsável por configurar tipos.
    private void configurarTipos() {
        campoTipoMaterial.getItems().setAll(Tipo.values());
        filtroTipo.getItems().setAll(Tipo.values());

        StringConverter<Tipo> conversor = new StringConverter<>() {
            @Override
            public String toString(Tipo tipo) {
                return formatarTipo(tipo);
            }

            @Override
            public Tipo fromString(String texto) {
                return null;
            }
        };

        campoTipoMaterial.setConverter(conversor);
        filtroTipo.setConverter(conversor);
    }

    // Método responsável por formatar tipo.
    private String formatarTipo(Tipo tipo) {
        if (tipo == null) {
            return "";
        }

        return tipo.name().replace("_", " ").toLowerCase().substring(0, 1).toUpperCase() + tipo.name().replace("_", " ").toLowerCase().substring(1);
    }

    // Cadastro e edição
    @FXML
    private void salvarMaterial() {
        Usuario usuario = TelaLoginController.getUsuarioLogado();

        if (usuario == null) {
            mostrarAlerta(Alert.AlertType.WARNING, "Acesso necessário", "Faça login para publicar um material.");
            return;
        }

        String titulo = campoTitulo.getText();
        String disciplina = campoDisciplina.getText();
        String descricao = campoDescricao.getText();
        String link = campoLink.getText();

        Tipo tipo = campoTipoMaterial.getValue();

        try {
            if (idEmEdicao == null) {
                controller.cadastrar(usuario.getEmail(), usuario.getNome(), titulo, descricao, disciplina, tipo, link);

                mostrarAlerta(Alert.AlertType.INFORMATION, "Material publicado", "Seu material foi publicado com sucesso.");
            } else {
                controller.editar(idEmEdicao, usuario.getEmail(), titulo, descricao, disciplina, tipo, link);

                mostrarAlerta(Alert.AlertType.INFORMATION, "Material atualizado", "As alterações foram salvas.");
            }

            limparFormulario();
            atualizarLista();
        } catch (IllegalArgumentException | IllegalStateException e) {
            mostrarAlerta(Alert.AlertType.WARNING, "Não foi possível salvar", e.getMessage());
        }
    }

    // Pesquisa e filtros
    @FXML
    private void pesquisarMateriais() {
        atualizarLista();
    }

    // Método utilizado para atualizar atualizar lista.
    private void atualizarLista() {
        if (listaMateriais == null) {
            return;
        }

        listaMateriais.getChildren().clear();

        String busca = campoBusca.getText();
        String disciplina = filtroDisciplina.getText();
        Tipo tipo = filtroTipo.getValue();

        List<MaterialEstudo> materiais = controller.pesquisar(busca, disciplina, tipo);

        labelQuantidade.setText(materiais.size() == 1 ? "1 material encontrado" : materiais.size() + " materiais encontrados");

        if (materiais.isEmpty()) {
            Label vazio = new Label("Nenhum material encontrado.\n" + "Experimente alterar sua pesquisa ou publicar um novo material.");

            vazio.setWrapText(true);
            vazio.setStyle("-fx-text-fill: #68758A;" + "-fx-padding: 18;" + "-fx-background-color: white;" + "-fx-background-radius: 10;");

            listaMateriais.getChildren().add(vazio);
            return;
        }

        for (MaterialEstudo material : materiais) {
            listaMateriais.getChildren().add(criarCardMaterial(material));
        }
    }

    // Criação dos cartões
    private VBox criarCardMaterial(MaterialEstudo material) {
        VBox card = new VBox(9);

        card.setStyle(
                "-fx-background-color: white;"
                + "-fx-background-radius: 12;"
                + "-fx-border-radius: 12;"
                + "-fx-border-color: #E1E6EF;"
                + "-fx-padding: 14;"
        );

        Label tipo = new Label(formatarTipo(material.getTipo()));

        tipo.setStyle(
                "-fx-background-color: #E8EEF8;"
                + "-fx-text-fill: #243B64;"
                + "-fx-padding: 5 9 5 9;"
                + "-fx-background-radius: 6;"
                + "-fx-font-size: 10px;"
                + "-fx-font-weight: bold;"
        );

        Label titulo = new Label(material.getTitulo());

        titulo.setWrapText(true);
        titulo.setStyle(
                "-fx-font-size: 16px;"
                + "-fx-font-weight: bold;"
                + "-fx-text-fill: #243B64;"
        );

        Label disciplina = new Label("Disciplina: " + material.getDisciplina());

        disciplina.setStyle("-fx-text-fill: #426A9E;");

        Label descricao = new Label(material.getDescricao());

        descricao.setWrapText(true);
        descricao.setStyle(
                "-fx-font-size: 12px;"
                + "-fx-text-fill: #4D596B;"
        );

        Label autor = new Label("Publicado por " + material.getAutorNome());

        autor.setStyle(
                "-fx-font-size: 11px;"
                + "-fx-text-fill: #68758A;"
        );

        Label data = new Label(material.getDataCriacao().format(formatoData));

        data.setStyle(
                "-fx-font-size: 10px;"
                + "-fx-text-fill: #8993A3;"
        );

        card.getChildren().addAll(tipo, titulo, disciplina);

        if (material.getDescricao() != null && !material.getDescricao().isBlank()) {
            card.getChildren().add(descricao);
        }

        card.getChildren().addAll(autor, data);

        if (material.getLink() != null && !material.getLink().isBlank()) {
            Hyperlink link = new Hyperlink("Acessar material");

            link.setOnAction(event -> abrirLink(material.getLink()));

            card.getChildren().add(link);
        }

        Usuario usuario = TelaLoginController.getUsuarioLogado();

        if (usuario != null && material.getAutorEmail().equalsIgnoreCase(usuario.getEmail())) {
            HBox botoes = new HBox(8);

            Button editar = new Button("Editar");
            Button excluir = new Button("Excluir");

            editar.setStyle(
                    "-fx-background-color: #E8EDF5;"
                    + "-fx-text-fill: #243B64;"
                    + "-fx-background-radius: 7;"
                    + "-fx-cursor: hand;"
            );

            excluir.setStyle(
                    "-fx-background-color: #FCEAEA;"
                    + "-fx-text-fill: #A33A3A;"
                    + "-fx-background-radius: 7;"
                    + "-fx-cursor: hand;"
            );

            editar.setOnAction(event -> carregarEdicao(material));

            excluir.setOnAction(event -> excluirMaterial(material));

            botoes.getChildren().addAll(editar, excluir);
            card.getChildren().add(botoes);
        }

        return card;
    }

    // Carrega os dados no formulário
    private void carregarEdicao(MaterialEstudo material) {
        idEmEdicao = material.getId();

        campoTitulo.setText(material.getTitulo());
        campoDisciplina.setText(material.getDisciplina());
        campoDescricao.setText(material.getDescricao());
        campoLink.setText(material.getLink());
        campoTipoMaterial.setValue(material.getTipo());

        botaoSalvar.setText("Salvar alterações");

        botaoCancelar.setVisible(true);
        botaoCancelar.setManaged(true);

        campoTitulo.requestFocus();
    }

    // Cancela a edição
    @FXML
    private void cancelarEdicao() {
        limparFormulario();
    }

    // Método responsável por limpar formulario.
    private void limparFormulario() {
        idEmEdicao = null;

        campoTitulo.clear();
        campoDisciplina.clear();
        campoDescricao.clear();
        campoLink.clear();
        campoTipoMaterial.setValue(null);

        botaoSalvar.setText("Publicar material");

        botaoCancelar.setVisible(false);
        botaoCancelar.setManaged(false);
    }

    // Exclusão
    private void excluirMaterial(MaterialEstudo material) {
        Alert confirmacao = new Alert(Alert.AlertType.CONFIRMATION);

        confirmacao.setTitle("Excluir material");
        confirmacao.setHeaderText("Deseja excluir este material?");
        confirmacao.setContentText(material.getTitulo());

        confirmacao.showAndWait().ifPresent(resposta -> {
            if (resposta == ButtonType.OK) {
                Usuario usuario = TelaLoginController.getUsuarioLogado();

                if (usuario == null) {
                    return;
                }

                try {
                    controller.excluir(material.getId(), usuario.getEmail());

                    if (material.getId().equals(idEmEdicao)) {
                        limparFormulario();
                    }

                    atualizarLista();
                } catch (IllegalStateException e) {
                    mostrarAlerta(Alert.AlertType.WARNING, "Operação não permitida", e.getMessage());
                }
            }
        });
    }

    // Abertura de links externos
    private void abrirLink(String endereco) {
        try {
            URI uri = URI.create(endereco.trim());

            String esquema = uri.getScheme();

            if (esquema == null || !(esquema.equalsIgnoreCase("http") || esquema.equalsIgnoreCase("https"))) {
                throw new IllegalArgumentException("O link precisa começar com http:// ou https://.");
            }

            if (!Desktop.isDesktopSupported() || !Desktop.getDesktop().isSupported(Desktop.Action.BROWSE)) {

                throw new UnsupportedOperationException("Não foi possível abrir o navegador neste computador.");
            }

            Desktop.getDesktop().browse(uri);
        } catch (Exception e) {
            mostrarAlerta(Alert.AlertType.WARNING, "Não foi possível abrir o link", e.getMessage());
        }
    }

    // Navegação
    @FXML
    private void voltarAcademico() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/TelaAcademica.fxml"));

            Parent root = loader.load();

            Stage stage = (Stage) listaMateriais.getScene().getWindow();

            stage.setScene(new Scene(root, 390, 844));
            stage.setTitle("CampusHub - Área Acadêmica");
            stage.show();
        } catch (IOException e) {
            mostrarAlerta(Alert.AlertType.ERROR, "Erro de navegação", "Não foi possível abrir a área acadêmica.");

            e.printStackTrace();
        }
    }

    // Método responsável por mostrar alerta.
    private void mostrarAlerta(Alert.AlertType tipo, String titulo, String mensagem) {
        Alert alerta = new Alert(tipo);

        alerta.setTitle(titulo);
        alerta.setHeaderText(null);
        alerta.setContentText(mensagem);

        alerta.showAndWait();
    }
}
