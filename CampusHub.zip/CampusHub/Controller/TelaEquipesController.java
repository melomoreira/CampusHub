// Define o pacote Controller, que organiza as classes do projeto.
package Controller;

// Importa as classes e bibliotecas utilizadas neste arquivo.
import Model.Equipe;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.List;

// Classe responsável por controlar as ações relacionadas a tela equipes.
public class TelaEquipesController {
    // Atributos
    @FXML
    private TextField campoBusca;

    @FXML
    private ComboBox<String> filtroSeletiva;

    @FXML
    private Label labelQuantidade;

    @FXML
    private VBox listaEquipes;

    private final EquipeController equipeController = EquipeController.getInstancia();

    @FXML
    private void initialize() {
        filtroSeletiva.getItems().addAll("Todas", "Com seletiva", "Sem seletiva");

        filtroSeletiva.setValue("Todas");

        campoBusca.textProperty().addListener((observable, valorAntigo, valorNovo) -> atualizarLista());

        atualizarLista();
    }

    @FXML
    private void filtrarEquipes() {
        atualizarLista();
    }

    // Método utilizado para atualizar atualizar lista.
    private void atualizarLista() {
        String pesquisa = campoBusca.getText();
        String filtro = filtroSeletiva.getValue();

        List<Equipe> resultados = equipeController.filtrar(pesquisa, filtro);

        listaEquipes.getChildren().clear();

        labelQuantidade.setText("Equipes encontradas: " + resultados.size());

        if (resultados.isEmpty()) {
            Label mensagem = new Label("Nenhuma equipe encontrada.");

            mensagem.setWrapText(true);

            mensagem.setStyle("-fx-font-size: 13px;" + "-fx-text-fill: #667085;" + "-fx-padding: 12px;");

            listaEquipes.getChildren().add(mensagem);
            return;
        }

        for (Equipe equipe : resultados) {
            listaEquipes.getChildren().add(criarCartao(equipe));
        }
    }

    // Método responsável por criar cartao.
    private VBox criarCartao(Equipe equipe) {
        VBox cartao = new VBox(8);

        cartao.setStyle("-fx-background-color: white;" + "-fx-background-radius: 12px;" + "-fx-padding: 15px;");

        Label titulo = new Label("🏆  " + equipe.getNome());

        titulo.setStyle("-fx-font-size: 16px;" + "-fx-font-weight: bold;" + "-fx-text-fill: #243B64;");

        Label modalidade = new Label("Modalidade: " + equipe.getModalidade());

        modalidade.setStyle("-fx-font-size: 12px;" + "-fx-font-weight: bold;" + "-fx-text-fill: #426A9E;");

        Label descricao = new Label(equipe.getDescricao());

        descricao.setWrapText(true);

        descricao.setStyle("-fx-font-size: 12px;" + "-fx-text-fill: #667085;");

        Label situacao = new Label(equipe.isPossuiSeletiva() ? "Seletiva: disponível para consulta" : "Seletiva: não cadastrada");

        situacao.setWrapText(true);

        situacao.setStyle("-fx-font-size: 12px;" + "-fx-font-weight: bold;" + "-fx-text-fill: #426A9E;");

        Label informacao = new Label(equipe.getInformacaoSeletiva());

        informacao.setWrapText(true);

        informacao.setStyle("-fx-font-size: 12px;" + "-fx-text-fill: #667085;");

        cartao.getChildren().addAll(titulo, modalidade, descricao, situacao, informacao);

        return cartao;
    }

    @FXML
    private void voltarAtletica() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/TelaAtletica.fxml"));

            Parent tela = loader.load();

            Stage stage = (Stage) listaEquipes.getScene().getWindow();

            stage.setScene(new Scene(tela, 390, 844));

            stage.setTitle("CampusHub - Atlética");

            stage.show();
        } catch (Exception e) {
            e.printStackTrace();

            Alert alerta = new Alert(Alert.AlertType.ERROR);

            alerta.setTitle("Erro de navegação");

            alerta.setHeaderText("Não foi possível retornar à Atlética.");

            alerta.setContentText(e.toString());

            alerta.showAndWait();
        }
    }
}
