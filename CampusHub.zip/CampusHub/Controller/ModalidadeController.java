// Define o pacote Controller, que organiza as classes do projeto.
package Controller;

// Importa as classes e bibliotecas utilizadas neste arquivo.
import Model.Modalidade;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

// Classe responsável por controlar as ações relacionadas a modalidade.
public class ModalidadeController {
    // Atributos
    private static final ModalidadeController instancia = new ModalidadeController();

    // Atributo utilizado para armazenar modalidades.
    private final ArrayList<Modalidade> modalidades;

    // Construtores
    private ModalidadeController() {
        modalidades = new ArrayList<>();

        carregarDadosDemonstrativos();
    }

    // Método utilizado para consultar instancia.
    public static ModalidadeController getInstancia() {
        return instancia;
    }

    // Dados demonstrativos: substituir pela relação oficial da Atlética.
    private void carregarDadosDemonstrativos() {
        modalidades.add(new Modalidade("Futsal", "Coletiva", "Modalidade esportiva praticada em equipe."));

        modalidades.add(new Modalidade("Voleibol", "Coletiva", "Esporte coletivo disputado entre duas equipes."));

        modalidades.add(new Modalidade("Basquetebol", "Coletiva", "Modalidade coletiva que envolve arremessos e trabalho em equipe."));

        modalidades.add(new Modalidade("Handebol", "Coletiva", "Esporte coletivo que combina passes, movimentação e arremessos."));

        modalidades.add(new Modalidade("Atletismo", "Individual", "Modalidade que reúne diferentes provas esportivas."));

        modalidades.add(new Modalidade("Natação", "Individual", "Modalidade esportiva praticada em ambiente aquático."));
    }

    // Retorna uma cópia da lista.
    public List<Modalidade> listarTodas() {
        return new ArrayList<>(modalidades);
    }

    // Pesquisa por nome e descrição, com filtro por categoria.
    public List<Modalidade> filtrar(String pesquisa, String categoria) {
        String termo = pesquisa == null ? "" : pesquisa.trim().toLowerCase(Locale.ROOT);

        return modalidades.stream().filter(modalidade -> {
                    boolean correspondePesquisa = modalidade.getNome().toLowerCase(Locale.ROOT).contains(termo) || modalidade.getDescricao().toLowerCase(Locale.ROOT).contains(termo);

                    boolean correspondeCategoria = categoria == null || categoria.equals("Todas") || modalidade.getCategoria().equals(categoria);

                    return correspondePesquisa && correspondeCategoria;
                }).toList();
    }
}
