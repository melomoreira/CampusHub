// Define o pacote Controller, que organiza as classes do projeto.
package Controller;

// Importa as classes e bibliotecas utilizadas neste arquivo.
import Model.NoticiaAtletica;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.List;

// Classe responsável por controlar as ações relacionadas a tela noticias atletica.
public class TelaNoticiasAtleticaController {
    // Atributos
    @FXML
    private TextField campoBusca;

    @FXML
    private ComboBox<String> filtroCategoria;

    @FXML
    private Label labelQuantidade;

    @FXML
    private VBox listaNoticias;

    private final NoticiaAtleticaController noticiaController = NoticiaAtleticaController.getInstancia();

    @FXML
    private void initialize() {
        filtroCategoria.getItems().addAll("Todas", "Comunicado", "Esportes", "Seletivas", "Eventos");

        filtroCategoria.setValue("Todas");

        campoBusca.textProperty().addListener((observable, valorAntigo, valorNovo) -> atualizarLista());

        atualizarLista();
    }

    @FXML
    private void filtrarNoticias() {
        atualizarLista();
    }

    // Método utilizado para atualizar atualizar lista.
    private void atualizarLista() {
        String pesquisa = campoBusca.getText();
        String categoria = filtroCategoria.getValue();

        List<NoticiaAtletica> resultados = noticiaController.filtrar(pesquisa, categoria);

        listaNoticias.getChildren().clear();

        labelQuantidade.setText("Notícias encontradas: " + resultados.size());

        if (resultados.isEmpty()) {
            Label mensagem = new Label("Nenhuma notícia ou comunicado encontrado.");

            mensagem.setWrapText(true);

            mensagem.setStyle("-fx-font-size: 13px;" + "-fx-text-fill: #667085;" + "-fx-padding: 12px;");

            listaNoticias.getChildren().add(mensagem);
            return;
        }

        for (NoticiaAtletica noticia : resultados) {
            listaNoticias.getChildren().add(criarCartao(noticia));
        }
    }

    // Método responsável por criar cartao.
    private VBox criarCartao(NoticiaAtletica noticia) {
        VBox cartao = new VBox(8);

        cartao.setStyle("-fx-background-color: white;" + "-fx-background-radius: 12px;" + "-fx-padding: 15px;");

        Label titulo = new Label("📢  " + noticia.getTitulo());

        titulo.setWrapText(true);

        titulo.setStyle("-fx-font-size: 16px;" + "-fx-font-weight: bold;" + "-fx-text-fill: #243B64;");

        Label categoria = new Label("Categoria: " + noticia.getCategoria());

        categoria.setStyle("-fx-font-size: 12px;" + "-fx-font-weight: bold;" + "-fx-text-fill: #426A9E;");

        Label conteudo = new Label(noticia.getConteudo());

        conteudo.setWrapText(true);

        conteudo.setStyle("-fx-font-size: 13px;" + "-fx-text-fill: #667085;");

        Label data = new Label("Data: " + noticia.getData());

        data.setStyle("-fx-font-size: 11px;" + "-fx-text-fill: #667085;");

        Label autor = new Label("Publicado por: " + noticia.getAutor());

        autor.setStyle("-fx-font-size: 11px;" + "-fx-text-fill: #667085;");

        cartao.getChildren().addAll(titulo, categoria, conteudo, data, autor);

        return cartao;
    }

    @FXML
    private void voltarAtletica() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/TelaAtletica.fxml"));

            Parent tela = loader.load();

            Stage stage = (Stage) listaNoticias.getScene().getWindow();

            stage.setScene(new Scene(tela, 390, 844));

            stage.setTitle("CampusHub - Atlética");

            stage.show();
        } catch (Exception e) {
            e.printStackTrace();

            Alert alerta = new Alert(Alert.AlertType.ERROR);

            alerta.setTitle("Erro de navegação");

            alerta.setHeaderText("Não foi possível retornar à Atlética.");

            alerta.setContentText(e.toString());

            alerta.showAndWait();
        }
    }
}
