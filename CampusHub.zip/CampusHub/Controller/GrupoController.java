// Define o pacote Controller, que organiza as classes do projeto.
package Controller;

// Importa as classes e bibliotecas utilizadas neste arquivo.
import Model.Grupo;
import Model.GrupoDAO;
import Model.Usuario;

import java.util.ArrayList;

// Classe responsável por controlar as ações relacionadas a grupo.
public class GrupoController {
    // Atributos
    private static GrupoController instancia;

    // Atributo utilizado para armazenar grupo dao.
    private final GrupoDAO grupoDAO;

    // Construtores
    private GrupoController() {
        grupoDAO = new GrupoDAO();
        cadastrarGruposIniciais();
    }

    // Método utilizado para consultar instance.
    public static GrupoController getInstance() {
        if (instancia == null) {
            instancia = new GrupoController();
        }
        return instancia;
    }

    // Cadastra os grupos padrão somente se ainda não existirem
    private void cadastrarGruposIniciais() {
        ArrayList<Grupo> existentes = grupoDAO.listarTodos();

        cadastrarSeNaoExistir(
            existentes,
            "Tecnologia e Programação",
            "Um espaço para compartilhar projetos, aprender programação e trocar experiências."
        );

        cadastrarSeNaoExistir(
            existentes,
            "Arte e Cultura",
            "Para quem gosta de música, literatura, cinema, desenho e outras expressões artísticas."
        );

        cadastrarSeNaoExistir(
            existentes,
            "Ciência e Pesquisa",
            "Conecte-se com estudantes interessados em pesquisa, ciência e iniciação acadêmica."
        );

        cadastrarSeNaoExistir(
            existentes,
            "Jogos e Cultura Geek",
            "Um ponto de encontro para fãs de jogos, RPG, tecnologia e cultura geek."
        );
    }

    // Método responsável por cadastrar se nao existir.
    private void cadastrarSeNaoExistir(ArrayList<Grupo> existentes, String nome, String descricao) {
        for (Grupo grupo : existentes) {
            if (grupo.getNome() != null && grupo.getNome().equalsIgnoreCase(nome)) {
                return;
            }
        }

        Grupo novoGrupo = new Grupo(nome, descricao, null);
        grupoDAO.salvar(novoGrupo);
    }

    // Cadastrar novo grupo
    public boolean cadastrarGrupo(Grupo grupo) {
        if (grupo == null || grupo.getNome() == null || grupo.getNome().trim().isEmpty()) {
            return false;
        }

        return grupoDAO.salvar(grupo);
    }

    // Listar todos os grupos
    public ArrayList<Grupo> listarGrupos() {
        return grupoDAO.listarTodos();
    }

    // Buscar grupo por ID
    public Grupo buscarGrupoPorId(String id) {
        if (id == null) {
            return null;
        }

        return grupoDAO.buscarPorId(id);
    }

    // Atualizar grupo
    public boolean atualizarGrupo(Grupo grupo) {
        if (grupo == null) {
            return false;
        }

        return grupoDAO.atualizar(grupo);
    }

    // Excluir grupo
    public boolean excluirGrupo(String id) {
        if (id == null) {
            return false;
        }

        return grupoDAO.excluir(id);
    }

    // Participar de um grupo
    public boolean participarGrupo(String grupoId, Usuario usuario) {
        if (grupoId == null || usuario == null) {
            return false;
        }

        return grupoDAO.participar(grupoId, usuario);
    }

    // Sair de um grupo
    public boolean sairGrupo(String grupoId, Usuario usuario) {
        if (grupoId == null || usuario == null) {
            return false;
        }

        return grupoDAO.sair(grupoId, usuario);
    }

    // Verificar se usuário participa do grupo
    public boolean usuarioParticipa(String grupoId, Usuario usuario) {
        if (grupoId == null || usuario == null) {
            return false;
        }

        return grupoDAO.usuarioParticipa(grupoId, usuario);
    }
}
