// Define o pacote Controller, que organiza as classes do projeto.
package Controller;

// Importa as classes e bibliotecas utilizadas neste arquivo.
import Model.Equipe;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

// Classe responsável por controlar as ações relacionadas a equipe.
public class EquipeController {
    // Atributos
    private static final EquipeController instancia = new EquipeController();

    // Atributo utilizado para armazenar equipes.
    private final ArrayList<Equipe> equipes;

    // Construtores
    private EquipeController() {
        equipes = new ArrayList<>();
        carregarDadosDemonstrativos();
    }

    // Método utilizado para consultar instancia.
    public static EquipeController getInstancia() {
        return instancia;
    }

    // Dados demonstrativos.
    private void carregarDadosDemonstrativos() {
        equipes.add(new Equipe(
                "Equipe de Futsal",
                "Futsal",
                "Equipe universitária de futsal da Atlética.",
                true,
                "Consulte a Atlética para informações sobre a próxima seletiva."
        ));

        equipes.add(new Equipe(
                "Equipe de Voleibol",
                "Voleibol",
                "Equipe universitária de voleibol.",
                true,
                "Consulte a Atlética para informações sobre a próxima seletiva."
        ));

        equipes.add(new Equipe(
                "Equipe de Basquetebol",
                "Basquetebol",
                "Equipe universitária de basquetebol.",
                false,
                "Não há seletiva cadastrada no momento."
        ));

        equipes.add(new Equipe(
                "Equipe de Handebol",
                "Handebol",
                "Equipe universitária de handebol.",
                false,
                "Não há seletiva cadastrada no momento."
        ));

        equipes.add(new Equipe(
                "Equipe de Atletismo",
                "Atletismo",
                "Equipe voltada às modalidades de atletismo.",
                true,
                "Consulte a Atlética para informações sobre a próxima seletiva."
        ));
    }

    // Método utilizado para consultar listar todas.
    public List<Equipe> listarTodas() {
        return new ArrayList<>(equipes);
    }

    // Método responsável por filtrar.
    public List<Equipe> filtrar(String pesquisa, String filtroSeletiva) {
        String termo = pesquisa == null ? "" : pesquisa.trim().toLowerCase(Locale.ROOT);

        return equipes.stream()
                .filter(equipe -> {
                    boolean correspondePesquisa = equipe.getNome().toLowerCase(Locale.ROOT).contains(termo) || equipe.getModalidade().toLowerCase(Locale.ROOT).contains(termo) || equipe.getDescricao().toLowerCase(Locale.ROOT).contains(termo);

                    boolean correspondeFiltro = true;

                    if ("Com seletiva".equals(filtroSeletiva)) {
                        correspondeFiltro = equipe.isPossuiSeletiva();
                    } else if ("Sem seletiva".equals(filtroSeletiva)) {
                        correspondeFiltro = !equipe.isPossuiSeletiva();
                    }

                    return correspondePesquisa && correspondeFiltro;
                }).toList();
    }
}
