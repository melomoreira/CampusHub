// Define o pacote Controller, que organiza as classes do projeto.
package Controller;

// Importa as classes e bibliotecas utilizadas neste arquivo.
import Model.Monitoria;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

// Classe responsável por controlar as ações relacionadas a monitoria.
public class MonitoriaController {
    // Atributos
    private static final MonitoriaController instancia = new MonitoriaController();

    // Atributo utilizado para armazenar monitorias.
    private final List<Monitoria> monitorias;

    // Construtores
    private MonitoriaController() {
        monitorias = new ArrayList<>();
    }

    // Método utilizado para consultar instancia.
    public static MonitoriaController getInstancia() {
        return instancia;
    }

    // Cadastrar monitoria
    public Monitoria cadastrar(String autorEmail, String autorNome, String disciplina, String titulo, String descricao, String modalidade, String localOuLink) {
        Monitoria monitoria = new Monitoria(autorEmail, autorNome, disciplina, titulo, descricao, modalidade, localOuLink);

        monitorias.add(monitoria);

        return monitoria;
    }

    // Listar todas, da mais recente para a mais antiga
    public List<Monitoria> listarTodas() {
        List<Monitoria> resultado = new ArrayList<>(monitorias);

        resultado.sort(Comparator.comparing(Monitoria::getDataCriacao).reversed());

        return resultado;
    }

    // Buscar pelo ID
    public Monitoria buscarPorId(String id) {
        for (Monitoria monitoria : monitorias) {
            if (monitoria.getId().equals(id)) {
                return monitoria;
            }
        }

        return null;
    }

    // Editar monitoria
    public boolean editar(String id, String autorEmail, String disciplina, String titulo, String descricao, String modalidade, String localOuLink) {
        Monitoria monitoria = buscarPorId(id);

        if (monitoria == null || !monitoria.getAutorEmail().equals(autorEmail)) {
            return false;
        }

        monitoria.setDisciplina(disciplina);
        monitoria.setTitulo(titulo);
        monitoria.setDescricao(descricao);
        monitoria.setModalidade(modalidade);
        monitoria.setLocalOuLink(localOuLink);

        return true;
    }

    // Excluir monitoria
    public boolean excluir(String id, String autorEmail) {
        Monitoria monitoria = buscarPorId(id);

        if (monitoria == null || !monitoria.getAutorEmail().equals(autorEmail)) {
            return false;
        }

        return monitorias.remove(monitoria);
    }
}
