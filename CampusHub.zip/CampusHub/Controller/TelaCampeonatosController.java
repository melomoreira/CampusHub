// Define o pacote Controller, que organiza as classes do projeto.
package Controller;

// Importa as classes e bibliotecas utilizadas neste arquivo.
import Model.Campeonato;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.List;

// Classe responsável por controlar as ações relacionadas a tela campeonatos.
public class TelaCampeonatosController {
    // Atributos
    @FXML
    private TextField campoBusca;

    @FXML
    private ComboBox<String> filtroStatus;

    @FXML
    private Label labelQuantidade;

    @FXML
    private VBox listaCampeonatos;

    private final CampeonatoController campeonatoController = CampeonatoController.getInstancia();

    @FXML
    private void initialize() {
        filtroStatus.getItems().addAll("Todos", "Planejado", "Em andamento", "Encerrado");

        filtroStatus.setValue("Todos");

        campoBusca.textProperty().addListener((observable, valorAntigo, valorNovo) -> atualizarLista());

        atualizarLista();
    }

    @FXML
    private void filtrarCampeonatos() {
        atualizarLista();
    }

    // Método utilizado para atualizar atualizar lista.
    private void atualizarLista() {
        String pesquisa = campoBusca.getText();
        String status = filtroStatus.getValue();

        List<Campeonato> resultados = campeonatoController.filtrar(pesquisa, status);

        listaCampeonatos.getChildren().clear();

        labelQuantidade.setText("Competições encontradas: " + resultados.size());

        if (resultados.isEmpty()) {
            Label mensagem = new Label("Nenhuma competição encontrada.");

            mensagem.setWrapText(true);

            mensagem.setStyle("-fx-font-size: 13px;" + "-fx-text-fill: #667085;" + "-fx-padding: 12px;");

            listaCampeonatos.getChildren().add(mensagem);
            return;
        }

        for (Campeonato campeonato : resultados) {
            listaCampeonatos.getChildren().add(criarCartao(campeonato));
        }
    }

    // Método responsável por criar cartao.
    private VBox criarCartao(Campeonato campeonato) {
        VBox cartao = new VBox(8);

        cartao.setStyle("-fx-background-color: white;" + "-fx-background-radius: 12px;" + "-fx-padding: 15px;");

        Label titulo = new Label("🏆  " + campeonato.getNome());

        titulo.setWrapText(true);

        titulo.setStyle("-fx-font-size: 16px;" + "-fx-font-weight: bold;" + "-fx-text-fill: #243B64;");

        Label modalidade = new Label("Modalidade: " + campeonato.getModalidade());

        modalidade.setWrapText(true);

        modalidade.setStyle("-fx-font-size: 12px;" + "-fx-font-weight: bold;" + "-fx-text-fill: #426A9E;");

        Label descricao = new Label(campeonato.getDescricao());

        descricao.setWrapText(true);

        descricao.setStyle("-fx-font-size: 12px;" + "-fx-text-fill: #667085;");

        Label periodo = new Label("Período: " + campeonato.getPeriodo());

        periodo.setWrapText(true);

        periodo.setStyle("-fx-font-size: 12px;" + "-fx-text-fill: #667085;");

        Label status = new Label("Situação: " + campeonato.getStatus());

        status.setWrapText(true);

        status.setStyle("-fx-font-size: 12px;" + "-fx-font-weight: bold;" + "-fx-text-fill: #426A9E;");

        cartao.getChildren().addAll(titulo, modalidade, descricao, periodo, status);

        return cartao;
    }

    @FXML
    private void voltarAtletica() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/TelaAtletica.fxml"));

            Parent tela = loader.load();

            Stage stage = (Stage) listaCampeonatos.getScene().getWindow();

            stage.setScene(new Scene(tela, 390, 844));

            stage.setTitle("CampusHub - Atlética");

            stage.show();
        } catch (Exception e) {
            e.printStackTrace();

            Alert alerta = new Alert(Alert.AlertType.ERROR);

            alerta.setTitle("Erro de navegação");

            alerta.setHeaderText("Não foi possível retornar à Atlética.");

            alerta.setContentText(e.toString());

            alerta.showAndWait();
        }
    }
}
