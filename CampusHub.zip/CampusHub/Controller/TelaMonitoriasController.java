// Define o pacote Controller, que organiza as classes do projeto.
package Controller;

// Importa as classes e bibliotecas utilizadas neste arquivo.
import Model.Monitoria;
import Model.Usuario;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.Cursor;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.time.format.DateTimeFormatter;
import java.util.Optional;

// Classe responsável por controlar as ações relacionadas a tela monitorias.
public class TelaMonitoriasController {
    // Atributos
    @FXML private TextField campoDisciplina;
    @FXML private TextField campoTitulo;
    @FXML private TextArea campoDescricao;
    @FXML private ComboBox<String> campoModalidade;
    @FXML private TextField campoLocalOuLink;

    @FXML private Button botaoCadastrar;
    @FXML private Button botaoCancelar;

    @FXML private VBox listaMonitorias;

    private final MonitoriaController monitoriaController = MonitoriaController.getInstancia();

    // Atributo utilizado para armazenar monitoria em edicao.
    private String monitoriaEmEdicao;

    private final DateTimeFormatter formatoData = DateTimeFormatter.ofPattern("dd/MM/yyyy 'às' HH:mm");

    @FXML
    private void initialize() {
        campoModalidade.getItems().addAll(
                "Presencial",
                "Online",
                "Híbrida"
        );

        atualizarMonitorias();
    }

    // Cadastrar ou salvar edição
    @FXML
    private void cadastrar() {
        Usuario usuario = TelaLoginController.getUsuarioLogado();

        if (usuario == null) {
            mostrarAlerta(
                    Alert.AlertType.WARNING,
                    "Sessão não encontrada",
                    "É necessário estar autenticado para cadastrar uma monitoria."
            );
            return;
        }

        String disciplina = campoDisciplina.getText().trim();
        String titulo = campoTitulo.getText().trim();
        String descricao = campoDescricao.getText().trim();
        String modalidade = campoModalidade.getValue();
        String localOuLink = campoLocalOuLink.getText().trim();

        if (disciplina.isEmpty() || titulo.isEmpty() || descricao.isEmpty() || modalidade == null || localOuLink.isEmpty()) {
            mostrarAlerta(
                    Alert.AlertType.WARNING,
                    "Campos obrigatórios",
                    "Preencha todos os campos para continuar."
            );
            return;
        }

        if (monitoriaEmEdicao == null) {
            monitoriaController.cadastrar(usuario.getEmail(), usuario.getNome(), disciplina, titulo, descricao, modalidade, localOuLink);
        } else {
            boolean editado = monitoriaController.editar(monitoriaEmEdicao, usuario.getEmail(), disciplina, titulo, descricao, modalidade, localOuLink);

            if (!editado) {
                mostrarAlerta(
                        Alert.AlertType.ERROR,
                        "Erro",
                        "Não foi possível editar esta monitoria."
                );
                return;
            }
        }

        limparFormulario();
        atualizarMonitorias();
    }

    // Atualizar listagem
    private void atualizarMonitorias() {
        listaMonitorias.getChildren().clear();

        for (Monitoria monitoria : monitoriaController.listarTodas()) {
            VBox cartao = new VBox(8);

            cartao.setMaxWidth(Double.MAX_VALUE);

            cartao.setStyle(
                    "-fx-background-color: white;" +
                    "-fx-background-radius: 12px;" +
                    "-fx-padding: 15px;"
            );

            Label disciplina = new Label(
                    monitoria.getDisciplina()
            );

            disciplina.setStyle(
                    "-fx-font-size: 12px;" +
                    "-fx-font-weight: bold;" +
                    "-fx-text-fill: #426A9E;"
            );

            Label titulo = new Label(
                    monitoria.getTitulo()
            );

            titulo.setWrapText(true);

            titulo.setStyle(
                    "-fx-font-size: 16px;" +
                    "-fx-font-weight: bold;" +
                    "-fx-text-fill: #243B64;"
            );

            Label autor = new Label(
                    "Publicado por " + monitoria.getAutorNome() +
                    " • " + monitoria.getDataCriacao().format(formatoData)
            );

            autor.setWrapText(true);

            autor.setStyle(
                    "-fx-font-size: 11px;" +
                    "-fx-text-fill: #667085;"
            );

            Label descricao = new Label(
                    monitoria.getDescricao()
            );

            descricao.setWrapText(true);

            descricao.setStyle(
                    "-fx-font-size: 13px;" +
                    "-fx-text-fill: #344054;"
            );

            Label modalidade = new Label(
                    "Modalidade: " + monitoria.getModalidade()
            );

            modalidade.setStyle(
                    "-fx-font-size: 12px;" +
                    "-fx-text-fill: #426A9E;"
            );

            Label localOuLink = new Label(
                    "Local ou link: " + monitoria.getLocalOuLink()
            );

            localOuLink.setWrapText(true);

            localOuLink.setStyle(
                    "-fx-font-size: 12px;" +
                    "-fx-text-fill: #667085;"
            );

            cartao.getChildren().addAll(
                    disciplina,
                    titulo,
                    autor,
                    descricao,
                    modalidade,
                    localOuLink
            );

            Usuario usuario = TelaLoginController.getUsuarioLogado();

            if (usuario != null && monitoria.getAutorEmail().equals(usuario.getEmail())) {
                Button editar = new Button("Editar");
                Button excluir = new Button("Excluir");

                editar.setCursor(Cursor.HAND);
                excluir.setCursor(Cursor.HAND);

                editar.setStyle(
                        "-fx-background-color: #E5EBF4;" +
                        "-fx-text-fill: #243B64;" +
                        "-fx-background-radius: 6px;"
                );

                excluir.setStyle(
                        "-fx-background-color: #FCE8E8;" +
                        "-fx-text-fill: #A12B2B;" +
                        "-fx-background-radius: 6px;"
                );

                editar.setOnAction(event ->
                        carregarEdicao(monitoria)
                );

                excluir.setOnAction(event ->
                        excluirMonitoria(monitoria)
                );

                HBox botoes = new HBox(8, editar, excluir);

                cartao.getChildren().add(botoes);
            }

            listaMonitorias.getChildren().add(cartao);
        }

        if (listaMonitorias.getChildren().isEmpty()) {
            Label vazio = new Label(
                    "Ainda não existem monitorias cadastradas."
            );

            vazio.setWrapText(true);

            vazio.setStyle(
                    "-fx-font-size: 13px;" +
                    "-fx-text-fill: #667085;"
            );

            listaMonitorias.getChildren().add(vazio);
        }
    }

    // Carregar monitoria para edição
    private void carregarEdicao(Monitoria monitoria) {
        monitoriaEmEdicao = monitoria.getId();

        campoDisciplina.setText(monitoria.getDisciplina());
        campoTitulo.setText(monitoria.getTitulo());
        campoDescricao.setText(monitoria.getDescricao());
        campoModalidade.setValue(monitoria.getModalidade());
        campoLocalOuLink.setText(monitoria.getLocalOuLink());

        botaoCadastrar.setText("Salvar alterações");

        botaoCancelar.setVisible(true);
        botaoCancelar.setManaged(true);

        campoDisciplina.requestFocus();
    }

    // Excluir monitoria
    private void excluirMonitoria(Monitoria monitoria) {
        Alert confirmacao = new Alert(Alert.AlertType.CONFIRMATION);

        confirmacao.setTitle("Excluir monitoria");
        confirmacao.setHeaderText("Deseja excluir esta monitoria?");
        confirmacao.setContentText(monitoria.getTitulo());

        Optional<ButtonType> resultado = confirmacao.showAndWait();

        if (resultado.isPresent() && resultado.get() == ButtonType.OK) {
            Usuario usuario = TelaLoginController.getUsuarioLogado();

            if (usuario == null) {
                return;
            }

            boolean excluido = monitoriaController.excluir(monitoria.getId(), usuario.getEmail());

            if (excluido) {
                atualizarMonitorias();

                if (monitoria.getId().equals(monitoriaEmEdicao)) {
                    limparFormulario();
                }
            }
        }
    }

    // Cancelar edição
    @FXML
    private void cancelarEdicao() {
        limparFormulario();
    }

    // Método responsável por limpar formulario.
    private void limparFormulario() {
        campoDisciplina.clear();
        campoTitulo.clear();
        campoDescricao.clear();
        campoModalidade.setValue(null);
        campoLocalOuLink.clear();

        monitoriaEmEdicao = null;

        botaoCadastrar.setText("Cadastrar monitoria");

        botaoCancelar.setVisible(false);
        botaoCancelar.setManaged(false);
    }

    // Voltar à tela acadêmica
    @FXML
    private void voltarAcademico() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/TelaAcademica.fxml"));

            Parent tela = loader.load();

            Stage stage = (Stage) listaMonitorias.getScene().getWindow();

            stage.setScene(new Scene(tela, 390, 844));
            stage.setTitle("CampusHub - Acadêmico");
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();

            mostrarAlerta(Alert.AlertType.ERROR, "Erro de navegação", e.getMessage());
        }
    }

    // Método responsável por mostrar alerta.
    private void mostrarAlerta(Alert.AlertType tipo, String titulo, String mensagem) {
        Alert alerta = new Alert(tipo);

        alerta.setTitle("CampusHub");
        alerta.setHeaderText(titulo);
        alerta.setContentText(mensagem);

        alerta.showAndWait();
    }
}
