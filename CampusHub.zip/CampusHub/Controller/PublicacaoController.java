// Define o pacote Controller, que organiza as classes do projeto.
package Controller;

// Importa as classes e bibliotecas utilizadas neste arquivo.
import Model.Publicacao;
import Model.PublicacaoDAO;

import java.sql.SQLException;
import java.util.List;

// Classe responsável por controlar as ações relacionadas a publicação.
public class PublicacaoController {
    // Atributos
    private static final PublicacaoController instancia = new PublicacaoController();

    // Atributo utilizado para armazenar publicacao dao.
    private final PublicacaoDAO publicacaoDAO;

    // Construtores
    private PublicacaoController() {
        publicacaoDAO = new PublicacaoDAO();
    }

    // Método utilizado para consultar instancia.
    public static PublicacaoController getInstancia() {
        return instancia;
    }

    // Cadastrar publicação
    public Publicacao cadastrar(String autorEmail, String autorNome, String titulo, String conteudo) {
        Publicacao publicacao = new Publicacao(autorEmail, autorNome, titulo, conteudo);

        try {
            publicacaoDAO.salvar(publicacao);
            return publicacao;
        } catch (SQLException e) {
            throw new IllegalStateException("Não foi possível cadastrar a publicação.", e);
        }
    }

    // Listar publicações da mais recente para a mais antiga
    public List<Publicacao> listarTodas() {
        try {
            return publicacaoDAO.listarTodas();
        } catch (SQLException e) {
            throw new IllegalStateException("Não foi possível listar as publicações.", e);
        }
    }

    // Buscar publicação pelo ID
    public Publicacao buscarPorId(String id) {
        try {
            return publicacaoDAO.buscarPorId(id);
        } catch (SQLException e) {
            throw new IllegalStateException("Não foi possível buscar a publicação.", e);
        }
    }

    // Editar publicação
    public boolean editar(String id, String autorEmail, String novoTitulo, String novoConteudo) {
        Publicacao publicacao = buscarPorId(id);

        if (publicacao == null || !publicacao.getAutorEmail().equals(autorEmail)) {
            return false;
        }

        publicacao.setTitulo(novoTitulo);
        publicacao.setConteudo(novoConteudo);

        try {
            return publicacaoDAO.atualizar(publicacao);
        } catch (SQLException e) {
            throw new IllegalStateException("Não foi possível editar a publicação.", e);
        }
    }

    // Excluir publicação
    public boolean excluir(String id, String autorEmail) {
        Publicacao publicacao = buscarPorId(id);

        if (publicacao == null || !publicacao.getAutorEmail().equals(autorEmail)) {
            return false;
        }

        try {
            return publicacaoDAO.excluir(id);
        } catch (SQLException e) {
            throw new IllegalStateException("Não foi possível excluir a publicação.", e);
        }
    }
}
