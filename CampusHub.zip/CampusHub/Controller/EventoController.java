// Define o pacote Controller, que organiza as classes do projeto.
package Controller;

// Importa as classes e bibliotecas utilizadas neste arquivo.
import Model.Evento;
import Model.Usuario;
import Model.EventoDAO;

import java.util.ArrayList;

// Classe responsável por controlar as ações relacionadas a evento.
public class EventoController {
    // Atributos
    private static final EventoController instancia = new EventoController();

    // Atributo utilizado para armazenar evento dao.
    private EventoDAO eventoDAO;

    // Construtor
    private EventoController() {
        eventoDAO = new EventoDAO();
    }

    // Getter
    public static EventoController getInstancia() {
        return instancia;
    }

    // CREATE: cadastrar evento
    public boolean cadastrarEvento(Evento evento) {
        if (evento == null) {
            return false;
        }

        return eventoDAO.salvar(evento);
    }

    // READ: listar todos os eventos
    public ArrayList<Evento> listarEventos() {
        return eventoDAO.listarTodos();
    }

    // READ: buscar evento pelo ID
    public Evento buscarEventoPorId(String id) {
        if (id == null) {
            return null;
        }

        return eventoDAO.buscarPorId(id);
    }

    // UPDATE: atualizar evento
    public boolean atualizarEvento(String id, Evento novosDados) {
        if (id == null || novosDados == null) {
            return false;
        }

        Evento evento = eventoDAO.buscarPorId(id);

        if (evento == null) {
            return false;
        }

        evento.setTitulo(novosDados.getTitulo());
        evento.setData(novosDados.getData());
        evento.setHorario(novosDados.getHorario());
        evento.setLocal(novosDados.getLocal());
        evento.setDescricao(novosDados.getDescricao());

        return eventoDAO.atualizar(evento);
    }

    // DELETE: excluir evento
    public boolean excluirEvento(String id) {
        if (id == null) {
            return false;
        }

        return eventoDAO.excluir(id);
    }

    // Inscrever usuário em evento
    public boolean participarEvento(String id, Usuario usuario) {
        if (id == null || usuario == null) {
            return false;
        }

        if (eventoDAO.buscarPorId(id) == null) {
            return false;
        }

        if (eventoDAO.usuarioParticipa(id, usuario)) {
            return false;
        }

        return eventoDAO.adicionarParticipante(id, usuario);
    }

    // Remover inscrição
    public boolean sairEvento(String id, Usuario usuario) {
        if (id == null || usuario == null) {
            return false;
        }

        if (!eventoDAO.usuarioParticipa(id, usuario)) {
            return false;
        }

        return eventoDAO.removerParticipante(id, usuario);
    }
}
