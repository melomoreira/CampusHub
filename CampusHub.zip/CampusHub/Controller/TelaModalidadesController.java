// Define o pacote Controller, que organiza as classes do projeto.
package Controller;

// Model
import Model.Modalidade;

// JavaFX
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.scene.control.Alert;

// Java
import java.util.List;

// Classe responsável por controlar as ações relacionadas a tela modalidades.
public class TelaModalidadesController {
    // Atributos
    @FXML
    private TextField campoBusca;

    @FXML
    private ComboBox<String> filtroCategoria;

    @FXML
    private Label labelQuantidade;

    @FXML
    private VBox listaModalidades;

    private final ModalidadeController modalidadeController = ModalidadeController.getInstancia();

    // Inicialização
    @FXML
    private void initialize() {
        filtroCategoria.getItems().addAll("Todas", "Coletiva", "Individual");

        filtroCategoria.setValue("Todas");

        campoBusca.textProperty().addListener(
                (observable, valorAntigo, valorNovo) -> {
                    atualizarLista();
                });

        atualizarLista();
    }

    // Filtragem
    @FXML
    private void filtrarModalidades() {
        atualizarLista();
    }

    // Método utilizado para atualizar atualizar lista.
    private void atualizarLista() {
        String pesquisa = campoBusca.getText();
        String categoria = filtroCategoria.getValue();

        List<Modalidade> resultados = modalidadeController.filtrar(pesquisa, categoria);

        listaModalidades.getChildren().clear();

        labelQuantidade.setText("Modalidades encontradas: " + resultados.size());

        if (resultados.isEmpty()) {
            Label mensagem = new Label("Nenhuma modalidade encontrada.");

            mensagem.setWrapText(true);

            mensagem.setStyle("-fx-font-size: 13px;" + "-fx-text-fill: #667085;" + "-fx-padding: 12px;");

            listaModalidades.getChildren().add(mensagem);

            return;
        }

        for (Modalidade modalidade : resultados) {
            listaModalidades.getChildren().add(criarCartao(modalidade));
        }
    }

    // Criação dos cartões
    private VBox criarCartao(Modalidade modalidade) {
        VBox cartao = new VBox(8);

        cartao.setStyle("-fx-background-color: white;" + "-fx-background-radius: 12px;" + "-fx-padding: 15px;");

        Label titulo = new Label("🏅  " + modalidade.getNome());

        titulo.setStyle("-fx-font-size: 16px;" + "-fx-font-weight: bold;" + "-fx-text-fill: #243B64;");

        Label categoria = new Label("Categoria: " + modalidade.getCategoria());

        categoria.setStyle("-fx-font-size: 12px;" + "-fx-font-weight: bold;" + "-fx-text-fill: #426A9E;");

        Label descricao = new Label(modalidade.getDescricao());

        descricao.setWrapText(true);

        descricao.setStyle("-fx-font-size: 12px;" + "-fx-text-fill: #667085;");

        cartao.getChildren().addAll(titulo, categoria, descricao);

        return cartao;
    }

    // Retorno à tela da Atlética
    @FXML
    private void voltarAtletica() {
        try {

            FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/TelaAtletica.fxml"));

            Parent tela = loader.load();

            Stage stage = (Stage) listaModalidades.getScene().getWindow();

            stage.setScene(new Scene(tela, 390, 844));

            stage.setTitle("CampusHub - Atlética");

            stage.show();
        } catch (Exception e) {
            e.printStackTrace();

            Alert alerta = new Alert(Alert.AlertType.ERROR);

            alerta.setTitle("Erro de navegação");

            alerta.setHeaderText("Não foi possível retornar à Atlética.");

            alerta.setContentText(e.toString());

            alerta.showAndWait();
        }
    }
}
