// Define o pacote Controller, que organiza as classes do projeto.
package Controller;

// Importa as classes e bibliotecas utilizadas neste arquivo.
import Model.NoticiaAtletica;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

// Classe responsável por controlar as ações relacionadas a notícia da atlética.
public class NoticiaAtleticaController {
    // Atributos
    private static final NoticiaAtleticaController instancia = new NoticiaAtleticaController();

    // Atributo utilizado para armazenar noticias.
    private final ArrayList<NoticiaAtletica> noticias;

    // Construtores
    private NoticiaAtleticaController() {
        noticias = new ArrayList<>();
        carregarDadosDemonstrativos();
    }

    // Método utilizado para consultar instancia.
    public static NoticiaAtleticaController getInstancia() {
        return instancia;
    }

    // Notícias demonstrativas
    private void carregarDadosDemonstrativos() {
        noticias.add(new NoticiaAtletica(
                "Bem-vindos à Atlética!",
                "Comunicado",
                "A Atlética é um espaço de integração, esporte e "
                + "convivência universitária. Acompanhe esta área "
                + "para ficar por dentro das novidades.",
                "19/11/2026",
                "Atlética"
        ));

        noticias.add(new NoticiaAtletica(
                "Novas atividades esportivas",
                "Esportes",
                "Estamos preparando atividades e oportunidades "
                + "para os estudantes participarem das modalidades "
                + "esportivas da universidade.",
                "19/11/2026",
                "Atlética"
        ));

        noticias.add(new NoticiaAtletica(
                "Fique atento às seletivas",
                "Seletivas",
                "Informações sobre seletivas, equipes e oportunidades "
                + "de participação serão divulgadas nesta seção.",
                "19/11/2026",
                "Atlética"
        ));

        noticias.add(new NoticiaAtletica(
                "Calendário esportivo",
                "Eventos",
                "Os próximos campeonatos e eventos esportivos "
                + "serão anunciados conforme a organização "
                + "da Atlética.",
                "19/11/2026",
                "Atlética"
        ));
    }

    // Método utilizado para consultar listar todas.
    public List<NoticiaAtletica> listarTodas() {
        return new ArrayList<>(noticias);
    }

    // Método responsável por filtrar.
    public List<NoticiaAtletica> filtrar(String pesquisa, String categoria) {
        String termo = pesquisa == null ? "" : pesquisa.trim().toLowerCase(Locale.ROOT);

        return noticias.stream().filter(noticia -> {
                    boolean correspondePesquisa = noticia.getTitulo().toLowerCase(Locale.ROOT).contains(termo) || noticia.getConteudo().toLowerCase(Locale.ROOT).contains(termo) || noticia.getAutor().toLowerCase(Locale.ROOT).contains(termo);

                    boolean correspondeCategoria = categoria == null || categoria.equals("Todas") || noticia.getCategoria().equals(categoria);

                    return correspondePesquisa && correspondeCategoria;
                })
                .toList();
    }
}
