// Define o pacote Controller, que organiza as classes do projeto.
package Controller;

// Importa as classes e bibliotecas utilizadas neste arquivo.
import Model.Usuario;
import Model.UsuarioDAO;

import java.sql.SQLException;
import java.util.ArrayList;

// Classe responsável por controlar as ações relacionadas a usuário.
public class UsuarioController {
    // Atributos
    private final UsuarioDAO usuarioDAO;

    // Construtor
    public UsuarioController() {
        usuarioDAO = new UsuarioDAO();
    }

    // Método responsável por cadastrar usuario.
    public void cadastrarUsuario(Usuario usuario) {
        try {
            usuarioDAO.salvar(usuario);
        } catch (SQLException e) {
            throw new IllegalStateException("Erro ao cadastrar usuário no banco de dados.", e);
        }
    }

    // Método responsável por cadastrar usuario seguro.
    public boolean cadastrarUsuarioSeguro(Usuario usuario) {
        if (usuario == null || usuario.getEmail() == null || usuario.getEmail().trim().isEmpty()) {
            return false;
        }

        if (usuario.getSenha() == null || usuario.getSenha().isEmpty()) {
            return false;
        }

        try {
            usuarioDAO.salvar(usuario);
            return true;
        } catch (SQLException e) {
            if (e.getErrorCode() == 19) {
                return false;
            }

            throw new IllegalStateException("Erro ao cadastrar usuário.", e);
        }
    }

    // Método utilizado para consultar listar usuarios.
    public ArrayList<Usuario> listarUsuarios() {
        try {
            return usuarioDAO.listarTodos();
        } catch (SQLException e) {
            throw new IllegalStateException("Erro ao listar usuários.", e);
        }
    }

    // Método utilizado para consultar buscar usuario.
    public Usuario buscarUsuario(String nome) {
        if (nome == null) {
            return null;
        }

        for (Usuario usuario : listarUsuarios()) {
            if (usuario.getNome() != null && usuario.getNome().equalsIgnoreCase(nome.trim())) {
                return usuario;
            }
        }

        return null;
    }

    // Método utilizado para consultar buscar usuario por email.
    public Usuario buscarUsuarioPorEmail(String email) {
        try {
            return usuarioDAO.buscarPorEmail(email);
        } catch (SQLException e) {
            throw new IllegalStateException("Erro ao buscar usuário por e-mail.", e);
        }
    }

    // Método utilizado para consultar listar universidades.
    public ArrayList<String> listarUniversidades() {
        try {
            return usuarioDAO.listarUniversidades();
        } catch (SQLException e) {
            throw new IllegalStateException("Erro ao listar universidades.", e);
        }
    }

    // Método responsável por autenticar usuario.
    public Usuario autenticarUsuario(String email, String senha) {
        try {
            return usuarioDAO.autenticar(email, senha);
        } catch (SQLException e) {
            throw new IllegalStateException("Erro ao autenticar usuário.", e);
        }
    }

    // Método utilizado para atualizar atualizar usuario.
    public boolean atualizarUsuario(String nome, String novoNome, String novaUniversidade, String novoCurso) {
        Usuario usuario = buscarUsuario(nome);

        if (usuario == null) {
            return false;
        }

        try {
            return usuarioDAO.atualizar(usuario.getEmail(), novoNome, novaUniversidade, novoCurso);
        } catch (SQLException e) {
            throw new IllegalStateException("Erro ao atualizar usuário.", e);
        }
    }

    // Método utilizado para atualizar atualizar perfil.
    public boolean atualizarPerfil(String emailAtual, Usuario usuario) {
        try {
            return usuarioDAO.atualizarPerfil(emailAtual, usuario);
        } catch (SQLException e) {
            // E-mail já pertencente a outro usuário.
            if (e.getErrorCode() == 19) {
                return false;
            }

            throw new IllegalStateException("Erro ao atualizar perfil.", e);
        }
    }

    // Método utilizado para remover excluir usuario.
    public boolean excluirUsuario(String nome) {
        Usuario usuario = buscarUsuario(nome);

        if (usuario == null) {
            return false;
        }

        try {
            return usuarioDAO.excluir(usuario.getEmail());
        } catch (SQLException e) {
            throw new IllegalStateException("Erro ao excluir usuário.", e);
        }
    }
}
