// Define o pacote Controller, que organiza as classes do projeto.
package Controller;

// Importa as classes e bibliotecas utilizadas neste arquivo.
import Model.MaterialEstudo;
import Model.MaterialEstudo.Tipo;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

// Classe responsável por controlar as ações relacionadas a material de estudo.
public class MaterialEstudoController {
    // Atributos
    private static final MaterialEstudoController instancia = new MaterialEstudoController();

    private final List<MaterialEstudo> materiais = new ArrayList<>();

    // Construtores
    private MaterialEstudoController() {
    }

    // Método utilizado para consultar instancia.
    public static MaterialEstudoController getInstancia() {
        return instancia;
    }

    // Cadastro
    public MaterialEstudo cadastrar(String autorEmail, String autorNome, String titulo, String descricao, String disciplina, Tipo tipo, String link) {
        validarDados(autorEmail, autorNome, titulo, disciplina, tipo);

        MaterialEstudo material = new MaterialEstudo(autorEmail.trim(), autorNome.trim(), titulo.trim(), limpar(descricao), disciplina.trim(), tipo, limpar(link));

        materiais.add(material);

        return material;
    }

    // Lista todos os materiais, dos mais recentes aos mais antigos
    public List<MaterialEstudo> listarTodos() {
        return materiais.stream().sorted(Comparator.comparing(MaterialEstudo::getDataCriacao).reversed()).toList();
    }

    // Pesquisa por ID
    public MaterialEstudo buscarPorId(String id) {
        if (id == null) {
            return null;
        }

        return materiais.stream().filter(m -> m.getId().equals(id)).findFirst().orElse(null);
    }

    // Pesquisa e filtragem
    public List<MaterialEstudo> pesquisar(String busca, String disciplina, Tipo tipo) {
        String termo = busca == null ? "" : busca.trim().toLowerCase(Locale.ROOT);

        String disciplinaFiltro = disciplina == null ? "" : disciplina.trim().toLowerCase(Locale.ROOT);

        return materiais.stream()
                .filter(m -> termo.isEmpty() || m.getTitulo().toLowerCase(Locale.ROOT).contains(termo) || m.getDisciplina().toLowerCase(Locale.ROOT).contains(termo)).filter(m -> disciplinaFiltro.isEmpty() || m.getDisciplina().toLowerCase(Locale.ROOT).equals(disciplinaFiltro)).filter(m -> tipo == null || m.getTipo() == tipo).sorted(Comparator.comparing(MaterialEstudo::getDataCriacao).reversed()).toList();
    }

    // Edição: somente o autor pode editar
    public boolean editar(String id, String emailUsuario, String titulo, String descricao, String disciplina, Tipo tipo, String link) {
        MaterialEstudo material = buscarPorId(id);

        if (material == null) {
            return false;
        }

        if (!material.getAutorEmail().equalsIgnoreCase(emailUsuario)) {
            throw new IllegalStateException("Somente o autor pode editar este material.");
        }

        validarDados(emailUsuario, material.getAutorNome(), titulo, disciplina, tipo);

        material.atualizarDados(titulo.trim(), limpar(descricao), disciplina.trim(), tipo, limpar(link));

        return true;
    }

    // Exclusão: somente o autor pode excluir
    public boolean excluir(String id, String emailUsuario) {
        MaterialEstudo material = buscarPorId(id);

        if (material == null) {
            return false;
        }

        if (!material.getAutorEmail().equalsIgnoreCase(emailUsuario)) {
            throw new IllegalStateException("Somente o autor pode excluir este material.");
        }

        materiais.remove(material);
        return true;
    }

    // Método utilizado para verificar validar dados.
    private void validarDados(String email, String nome, String titulo, String disciplina, Tipo tipo) {
        if (email == null || email.isBlank() || nome == null || nome.isBlank() || titulo == null || titulo.isBlank() || disciplina == null || disciplina.isBlank() || tipo == null) {
            throw new IllegalArgumentException("Preencha os campos obrigatórios.");
        }
    }

    // Método responsável por limpar.
    private String limpar(String valor) {
        return valor == null ? "" : valor.trim();
    }
}
