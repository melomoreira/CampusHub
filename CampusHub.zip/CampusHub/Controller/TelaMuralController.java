// Define o pacote Controller, que organiza as classes do projeto.
package Controller;

// Importa as classes e bibliotecas utilizadas neste arquivo.
import Model.Publicacao;
import Model.Usuario;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.Cursor;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.time.format.DateTimeFormatter;
import java.util.Optional;

// Classe responsável por controlar as ações relacionadas a tela mural.
public class TelaMuralController {
    // Atributos
    @FXML private TextField campoTitulo;
    @FXML private TextArea campoConteudo;

    @FXML private Button botaoPublicar;
    @FXML private Button botaoCancelar;

    @FXML private VBox listaPublicacoes;

    private final PublicacaoController publicacaoController = PublicacaoController.getInstancia();

    // Atributo utilizado para armazenar publicacao em edicao.
    private String publicacaoEmEdicao;

    private final DateTimeFormatter formatoData = DateTimeFormatter.ofPattern("dd/MM/yyyy 'às' HH:mm");

    @FXML
    private void initialize() {
        atualizarPublicacoes();
    }

    // Publicar ou salvar edição
    @FXML
    private void publicar() {
        Usuario usuario = TelaLoginController.getUsuarioLogado();

        if (usuario == null) {
            mostrarAlerta(
                    Alert.AlertType.WARNING,
                    "Sessão não encontrada",
                    "É necessário estar autenticado para publicar."
            );
            return;
        }

        String titulo = campoTitulo.getText().trim();
        String conteudo = campoConteudo.getText().trim();

        if (titulo.isEmpty() || conteudo.isEmpty()) {
            mostrarAlerta(
                    Alert.AlertType.WARNING,
                    "Campos obrigatórios",
                    "Preencha o título e o conteúdo da publicação."
            );
            return;
        }

        if (publicacaoEmEdicao == null) {
            publicacaoController.cadastrar(usuario.getEmail(), usuario.getNome(), titulo, conteudo);
        } else {
            boolean editado = publicacaoController.editar(publicacaoEmEdicao, usuario.getEmail(), titulo, conteudo);

            if (!editado) {
                mostrarAlerta(
                        Alert.AlertType.ERROR,
                        "Erro",
                        "Não foi possível editar esta publicação."
                );
                return;
            }
        }

        limparFormulario();
        atualizarPublicacoes();
    }

    // Atualizar lista de publicações
    private void atualizarPublicacoes() {
        listaPublicacoes.getChildren().clear();

        for (Publicacao publicacao : publicacaoController.listarTodas()) {
            VBox cartao = new VBox(8);

            cartao.setMaxWidth(Double.MAX_VALUE);

            cartao.setStyle(
                    "-fx-background-color: white;" +
                    "-fx-background-radius: 12px;" +
                    "-fx-padding: 15px;"
            );

            Label titulo = new Label(publicacao.getTitulo());

            titulo.setWrapText(true);

            titulo.setStyle(
                    "-fx-font-size: 16px;" +
                    "-fx-font-weight: bold;" +
                    "-fx-text-fill: #243B64;"
            );

            Label autor = new Label(
                    publicacao.getAutorNome() + " • " +
                    publicacao.getDataCriacao().format(formatoData)
            );

            autor.setWrapText(true);

            autor.setStyle(
                    "-fx-font-size: 11px;" +
                    "-fx-text-fill: #667085;"
            );

            Label conteudo = new Label(publicacao.getConteudo());

            conteudo.setWrapText(true);

            conteudo.setStyle(
                    "-fx-font-size: 13px;" +
                    "-fx-text-fill: #344054;"
            );

            cartao.getChildren().addAll(titulo, autor, conteudo);

            Usuario usuario = TelaLoginController.getUsuarioLogado();

            if (usuario != null && publicacao.getAutorEmail().equals(usuario.getEmail())) {
                Button editar = new Button("Editar");
                Button excluir = new Button("Excluir");

                editar.setCursor(Cursor.HAND);
                excluir.setCursor(Cursor.HAND);

                editar.setStyle(
                        "-fx-background-color: #E5EBF4;" +
                        "-fx-text-fill: #243B64;" +
                        "-fx-background-radius: 6px;"
                );

                excluir.setStyle(
                        "-fx-background-color: #FCE8E8;" +
                        "-fx-text-fill: #A12B2B;" +
                        "-fx-background-radius: 6px;"
                );

                editar.setOnAction(event ->
                        carregarEdicao(publicacao)
                );

                excluir.setOnAction(event ->
                        excluirPublicacao(publicacao)
                );

                HBox botoes = new HBox(8, editar, excluir);

                cartao.getChildren().add(botoes);
            }

            listaPublicacoes.getChildren().add(cartao);
        }

        if (listaPublicacoes.getChildren().isEmpty()) {
            Label vazio = new Label(
                    "Ainda não existem publicações. Seja o primeiro a compartilhar algo!"
            );

            vazio.setWrapText(true);

            vazio.setStyle(
                    "-fx-text-fill: #667085;" +
                    "-fx-font-size: 13px;"
            );

            listaPublicacoes.getChildren().add(vazio);
        }
    }

    // Carregar publicação para edição
    private void carregarEdicao(Publicacao publicacao) {
        publicacaoEmEdicao = publicacao.getId();

        campoTitulo.setText(publicacao.getTitulo());
        campoConteudo.setText(publicacao.getConteudo());

        botaoPublicar.setText("Salvar alterações");

        botaoCancelar.setVisible(true);
        botaoCancelar.setManaged(true);

        campoTitulo.requestFocus();
    }

    // Excluir publicação
    private void excluirPublicacao(Publicacao publicacao) {
        Alert confirmacao = new Alert(Alert.AlertType.CONFIRMATION);

        confirmacao.setTitle("Excluir publicação");
        confirmacao.setHeaderText("Deseja excluir esta publicação?");
        confirmacao.setContentText(publicacao.getTitulo());

        Optional<ButtonType> resultado = confirmacao.showAndWait();

        if (resultado.isPresent() && resultado.get() == ButtonType.OK) {
            Usuario usuario = TelaLoginController.getUsuarioLogado();

            if (usuario == null) {
                return;
            }

            boolean excluido = publicacaoController.excluir(
                    publicacao.getId(),
                    usuario.getEmail()
            );

            if (excluido) {
                atualizarPublicacoes();

                if (publicacao.getId().equals(publicacaoEmEdicao)) {
                    limparFormulario();
                }
            }
        }
    }

    // Cancelar edição
    @FXML
    private void cancelarEdicao() {
        limparFormulario();
    }

    // Método responsável por limpar formulario.
    private void limparFormulario() {
        campoTitulo.clear();
        campoConteudo.clear();

        publicacaoEmEdicao = null;

        botaoPublicar.setText("Publicar");

        botaoCancelar.setVisible(false);
        botaoCancelar.setManaged(false);
    }

    // Voltar à tela acadêmica
    @FXML
    private void voltarAcademico() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/TelaAcademica.fxml"));

            Parent tela = loader.load();

            Stage stage = (Stage) listaPublicacoes.getScene().getWindow();

            stage.setScene(new Scene(tela, 390, 844));
            stage.setTitle("CampusHub - Acadêmico");
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();

            mostrarAlerta(Alert.AlertType.ERROR, "Erro de navegação", e.getMessage());
        }
    }

    // Método responsável por mostrar alerta.
    private void mostrarAlerta(Alert.AlertType tipo, String titulo, String mensagem) {
        Alert alerta = new Alert(tipo);

        alerta.setTitle("CampusHub");
        alerta.setHeaderText(titulo);
        alerta.setContentText(mensagem);

        alerta.showAndWait();
    }
}
