// Define o pacote Controller, que organiza as classes do projeto.
package Controller;

// Importa as classes e bibliotecas utilizadas neste arquivo.
import Model.CompromissoAcademico;
import Model.CompromissoAcademico.Categoria;
import Model.CompromissoAcademico.Tipo;
import Model.Usuario;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.Cursor;
import javafx.scene.control.*;
import javafx.scene.layout.*;

import javafx.stage.Stage;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;

// Classe responsável por controlar as ações relacionadas a tela agenda.
public class TelaAgendaController {
    // Atributos
    @FXML private Label labelMes;
    @FXML private Label labelDataSelecionada;

    @FXML private GridPane gradeCalendario;

    @FXML private VBox listaCompromissos;
    @FXML private VBox listaSugestoes;

    @FXML private ComboBox<Tipo> campoTipo;
    @FXML private ComboBox<Categoria> campoCategoria;

    @FXML private TextField campoTitulo;
    @FXML private TextArea campoDescricao;
    @FXML private DatePicker campoData;
    @FXML private TextField campoHoraInicio;
    @FXML private TextField campoHoraFim;
    @FXML private TextField campoLocal;

    @FXML private Button botaoSalvar;
    @FXML private Button botaoCancelar;

    private final AgendaAcademicaController agendaController = AgendaAcademicaController.getInstancia();

    private YearMonth mesAtual = YearMonth.now();

    private LocalDate dataSelecionada = LocalDate.now();

    // Atributo utilizado para armazenar id em edicao.
    private String idEmEdicao = null;

    private final DateTimeFormatter formatoHora = DateTimeFormatter.ofPattern("H:mm");

    private final DateTimeFormatter formatoData = DateTimeFormatter.ofPattern("dd/MM/yyyy", new Locale("pt", "BR"));

    @FXML
    public void initialize() {
        campoTipo.getItems().setAll(Tipo.PESSOAL, Tipo.EVENTO_ACADEMICO);

        campoTipo.setValue(Tipo.PESSOAL);

        atualizarCategorias();

        campoTipo.setOnAction(event -> atualizarCategorias());

        campoData.setValue(LocalDate.now());

        atualizarCalendario();
        atualizarCompromissos();
        atualizarSugestoes();
    }

    // ==========================================
    // CALENDÁRIO
    // ==========================================

    @FXML
    private void mesAnterior() {
        mesAtual = mesAtual.minusMonths(1);
        atualizarCalendario();
    }

    @FXML
    private void proximoMes() {
        mesAtual = mesAtual.plusMonths(1);
        atualizarCalendario();
    }

    // Método utilizado para atualizar atualizar calendario.
    private void atualizarCalendario() {
        gradeCalendario.getChildren().clear();

        labelMes.setText(mesAtual.getMonth().getDisplayName(java.time.format.TextStyle.FULL, new Locale("pt", "BR")) + " " + mesAtual.getYear());

        String[] diasSemana = {
                "D", "S", "T", "Q", "Q", "S", "S"
        };

        for (int coluna = 0; coluna < 7; coluna++) {
            Label dia = new Label(diasSemana[coluna]);

            dia.setMaxWidth(Double.MAX_VALUE);
            dia.setAlignment(javafx.geometry.Pos.CENTER);

            dia.setStyle("-fx-text-fill: #68758A;" + "-fx-font-weight: bold;");

            gradeCalendario.add(dia, coluna, 0);
        }

        LocalDate primeiroDia = mesAtual.atDay(1);

        int deslocamento = primeiroDia.getDayOfWeek().getValue() % 7;

        int quantidadeDias = mesAtual.lengthOfMonth();

        for (int dia = 1; dia <= quantidadeDias; dia++) {
            LocalDate data = mesAtual.atDay(dia);

            int coluna = (deslocamento + dia - 1) % 7;

            int linha = (deslocamento + dia - 1) / 7 + 1;

            Button botaoDia = new Button(String.valueOf(dia));

            botaoDia.setMaxWidth(Double.MAX_VALUE);
            botaoDia.setPrefHeight(35);
            botaoDia.setCursor(Cursor.HAND);

            boolean possuiCompromisso = possuiCompromissoNaData(data);

            String estilo = "-fx-background-radius: 8;" + "-fx-border-radius: 8;";

            if (data.equals(dataSelecionada)) {
                estilo += "-fx-background-color: #243B64;" + "-fx-text-fill: white;" + "-fx-font-weight: bold;";
            } else if (possuiCompromisso) {
                estilo += "-fx-background-color: #AFC7E8;" + "-fx-text-fill: #243B64;" + "-fx-font-weight: bold;";
            } else {
                estilo += "-fx-background-color: #F4F6FA;" + "-fx-text-fill: #243B64;";
            }

            botaoDia.setStyle(estilo);

            botaoDia.setOnAction(event -> {
                dataSelecionada = data;

                atualizarCalendario();
                atualizarCompromissos();
            });

            gradeCalendario.add(botaoDia, coluna, linha);
        }
    }

    // Método responsável por possui compromisso na data.
    private boolean possuiCompromissoNaData(LocalDate data) {
        Usuario usuario = TelaLoginController.getUsuarioLogado();

        if (usuario == null) {
            return false;
        }

        List<CompromissoAcademico> compromissos = agendaController.listarAgendaUsuario(usuario.getEmail());

        for (CompromissoAcademico c : compromissos) {
            if (c.getInicio().toLocalDate().equals(data)) {
                return true;
            }
        }

        return false;
    }

    // ==========================================
    // LISTA DE COMPROMISSOS
    // ==========================================

    // Método utilizado para atualizar atualizar compromissos.
    private void atualizarCompromissos() {
        listaCompromissos.getChildren().clear();

        labelDataSelecionada.setText("Compromissos de " + dataSelecionada.format(formatoData));

        Usuario usuario = TelaLoginController.getUsuarioLogado();

        if (usuario == null) {
            adicionarMensagem(listaCompromissos, "Entre na sua conta para visualizar a agenda.");
            return;
        }

        List<CompromissoAcademico> compromissos = agendaController.listarAgendaUsuario(usuario.getEmail());

        boolean encontrou = false;

        for (CompromissoAcademico c : compromissos) {
            if (c.getInicio().toLocalDate().equals(dataSelecionada)) {
                listaCompromissos.getChildren().add(criarCardCompromisso(c, usuario));

                encontrou = true;
            }
        }

        if (!encontrou) {
            adicionarMensagem(listaCompromissos, "Nenhum compromisso para este dia.");
        }
    }

    // Método responsável por criar card compromisso.
    private VBox criarCardCompromisso(CompromissoAcademico c, Usuario usuario) {
        VBox card = new VBox(7);

        card.setStyle(
                "-fx-background-color: #F4F6FA;"
                + "-fx-background-radius: 9;"
                + "-fx-padding: 12;"
        );

        Label titulo = new Label(c.getTitulo());

        titulo.setStyle(
                "-fx-font-size: 14px;"
                + "-fx-font-weight: bold;"
                + "-fx-text-fill: #243B64;"
        );

        Label horario = new Label(
                "Horário: "
                + c.getInicio().toLocalTime()
                        .format(formatoHora)
                + (c.getFim() != null
                        ? " até "
                        + c.getFim().toLocalTime()
                                .format(formatoHora)
                        : "")
        );

        Label categoria = new Label(
                "Categoria: " + c.getCategoria()
        );

        Label tipo = new Label(
                c.getTipo() == Tipo.PESSOAL
                        ? "Compromisso pessoal"
                        : "Evento acadêmico"
        );

        Label local = new Label(
                "Local: "
                + (c.getLocal() == null
                        || c.getLocal().isBlank()
                        ? "Não informado"
                        : c.getLocal())
        );

        horario.setStyle("-fx-text-fill: #68758A;");
        categoria.setStyle("-fx-text-fill: #68758A;");
        tipo.setStyle("-fx-text-fill: #426A9E;");
        local.setStyle("-fx-text-fill: #68758A;");

        card.getChildren().addAll(titulo, horario, categoria, tipo, local);

        if (c.getDescricao() != null && !c.getDescricao().isBlank()) {
            Label descricao = new Label(c.getDescricao());

            descricao.setWrapText(true);

            card.getChildren().add(descricao);
        }

        boolean ehDono = c.getCriadorEmail().equalsIgnoreCase(usuario.getEmail());

        if (ehDono) {
            HBox acoes = new HBox(8);

            Button editar = new Button("Editar");
            Button excluir = new Button("Excluir");

            editar.setOnAction(event -> carregarEdicao(c));

            excluir.setOnAction(event -> excluirCompromisso(c));

            acoes.getChildren().addAll(editar, excluir);

            card.getChildren().add(acoes);
        }

        return card;
    }

    // ==========================================
    // CADASTRO E EDIÇÃO
    // ==========================================

    @FXML
    private void salvarCompromisso() {
        Usuario usuario = TelaLoginController.getUsuarioLogado();

        if (usuario == null) {
            mostrarAlerta(Alert.AlertType.WARNING, "Login necessário", "Entre na sua conta para utilizar a agenda.");
            return;
        }

        try {
            String titulo = campoTitulo.getText().trim();

            String descricao = campoDescricao.getText().trim();

            String local = campoLocal.getText().trim();

            LocalDate data = campoData.getValue();

            if (data == null) {
                throw new IllegalArgumentException("Selecione uma data.");
            }

            if (campoHoraInicio.getText().isBlank()) {
                throw new IllegalArgumentException("Informe o horário de início.");
            }

            LocalTime horaInicio = LocalTime.parse(campoHoraInicio.getText().trim(), formatoHora);

            LocalDateTime inicio = LocalDateTime.of(data, horaInicio);

            LocalDateTime fim = null;

            if (!campoHoraFim.getText().isBlank()) {

                LocalTime horaFim = LocalTime.parse(campoHoraFim.getText().trim(), formatoHora);

                fim = LocalDateTime.of(data, horaFim);
            }

            Tipo tipo = campoTipo.getValue();

            Categoria categoria = campoCategoria.getValue();

            if (tipo == null || categoria == null) {
                throw new IllegalArgumentException("Selecione o tipo e a categoria.");
            }

            if (idEmEdicao == null) {
                if (tipo == Tipo.PESSOAL) {
                    agendaController.cadastrarCompromissoPessoal(usuario.getEmail(), usuario.getNome(), titulo, descricao, inicio, fim, local, categoria);
                } else {
                    agendaController.sugerirEventoAcademico(usuario.getEmail(), usuario.getNome(), titulo, descricao, inicio, fim, local, categoria);

                    mostrarAlerta(Alert.AlertType.INFORMATION, "Sugestão enviada", "Seu evento foi enviado para análise. " + "Ele aparecerá na agenda coletiva " + "após a aprovação.");
                }
            } else {
                boolean atualizado = agendaController.editar(idEmEdicao, usuario.getEmail(), titulo, descricao, inicio, fim, local, categoria);

                if (!atualizado) {
                    throw new IllegalArgumentException("Não foi possível editar este compromisso.");
                }

                if (tipo == Tipo.EVENTO_ACADEMICO) {
                    mostrarAlerta(Alert.AlertType.INFORMATION, "Evento atualizado", "A alteração foi enviada para uma nova aprovação.");
                }
            }

            limparFormulario();

            dataSelecionada = data;
            mesAtual = YearMonth.from(data);

            atualizarCalendario();
            atualizarCompromissos();
            atualizarSugestoes();
        } catch (IllegalArgumentException e) {
            mostrarAlerta(Alert.AlertType.WARNING, "Verifique os dados", e.getMessage());
        } catch (Exception e) {
            mostrarAlerta(Alert.AlertType.WARNING, "Dados inválidos", "Confira o horário informado. Utilize o formato HH:mm.");
        }
    }

    // Método responsável por carregar edicao.
    private void carregarEdicao(CompromissoAcademico c) {
        idEmEdicao = c.getId();

        campoTipo.setValue(c.getTipo());
        campoTipo.setDisable(true);

        atualizarCategorias();

        campoCategoria.setValue(c.getCategoria());

        campoTitulo.setText(c.getTitulo());
        campoDescricao.setText(c.getDescricao());

        campoData.setValue(c.getInicio().toLocalDate());

        campoHoraInicio.setText(c.getInicio().toLocalTime().format(formatoHora));

        campoHoraFim.setText(c.getFim() == null ? "" : c.getFim().toLocalTime().format(formatoHora));

        campoLocal.setText(c.getLocal());

        botaoSalvar.setText("Salvar alterações");

        botaoCancelar.setVisible(true);
        botaoCancelar.setManaged(true);
    }

    @FXML
    private void cancelarEdicao() {
        limparFormulario();
    }

    // Método responsável por limpar formulario.
    private void limparFormulario() {
        idEmEdicao = null;

        campoTipo.setDisable(false);
        campoTipo.setValue(Tipo.PESSOAL);

        atualizarCategorias();

        campoTitulo.clear();
        campoDescricao.clear();
        campoHoraInicio.clear();
        campoHoraFim.clear();
        campoLocal.clear();

        campoData.setValue(LocalDate.now());

        botaoSalvar.setText("Adicionar à agenda");

        botaoCancelar.setVisible(false);
        botaoCancelar.setManaged(false);
    }

    // ==========================================
    // EXCLUSÃO
    // ==========================================

    // Método utilizado para remover excluir compromisso.
    private void excluirCompromisso(CompromissoAcademico c) {
        Alert confirmacao = new Alert(Alert.AlertType.CONFIRMATION);

        confirmacao.setTitle("Excluir compromisso");
        confirmacao.setHeaderText("Deseja excluir este compromisso?");

        confirmacao.setContentText(c.getTitulo());

        if (confirmacao.showAndWait().orElse(ButtonType.CANCEL) == ButtonType.OK) {
            Usuario usuario = TelaLoginController.getUsuarioLogado();

            if (usuario != null) {
                boolean excluido = agendaController.excluir(c.getId(), usuario.getEmail());

                if (excluido) {
                    atualizarCalendario();
                    atualizarCompromissos();
                    atualizarSugestoes();
                }
            }
        }
    }

    // ==========================================
    // MINHAS SUGESTÕES
    // ==========================================

    // Método utilizado para atualizar atualizar sugestoes.
    private void atualizarSugestoes() {
        listaSugestoes.getChildren().clear();

        Usuario usuario = TelaLoginController.getUsuarioLogado();

        if (usuario == null) {
            adicionarMensagem(listaSugestoes, "Entre na sua conta para consultar suas sugestões.");
            return;
        }

        List<CompromissoAcademico> sugestoes = agendaController.listarMinhasSugestoes(usuario.getEmail());

        if (sugestoes.isEmpty()) {
            adicionarMensagem(listaSugestoes, "Você ainda não sugeriu nenhum evento.");

            return;
        }

        for (CompromissoAcademico c : sugestoes) {
            VBox card = new VBox(6);

            card.setStyle(
                    "-fx-background-color: #F4F6FA;"
                    + "-fx-background-radius: 9;"
                    + "-fx-padding: 12;"
            );

            Label titulo = new Label(c.getTitulo());

            titulo.setStyle(
                    "-fx-font-weight: bold;"
                    + "-fx-text-fill: #243B64;"
            );

            Label data = new Label(
                    c.getInicio().format(
                            DateTimeFormatter.ofPattern(
                                    "dd/MM/yyyy HH:mm"
                            )
                    )
            );

            Label status = new Label(
                    "Status: " + c.getStatus()
            );

            status.setStyle(
                    "-fx-text-fill: #426A9E;"
                    + "-fx-font-weight: bold;"
            );

            card.getChildren().addAll(titulo, data, status);

            if (c.getStatus() == CompromissoAcademico.Status.REJEITADO) {
                Label aviso = new Label("Esta sugestão não foi aprovada.");

                aviso.setWrapText(true);

                card.getChildren().add(aviso);
            }

            Button editar = new Button("Editar");
            Button excluir = new Button("Excluir");

            editar.setOnAction(event -> carregarEdicao(c));

            excluir.setOnAction(event -> excluirCompromisso(c));

            HBox acoes = new HBox(8, editar, excluir);

            card.getChildren().add(acoes);

            listaSugestoes.getChildren().add(card);
        }
    }

    // ==========================================
    // CATEGORIAS
    // ==========================================

    // Método utilizado para atualizar atualizar categorias.
    private void atualizarCategorias() {
        Tipo tipo = campoTipo.getValue();

        if (tipo == Tipo.EVENTO_ACADEMICO) {
            campoCategoria.getItems().setAll(Categoria.PALESTRA, Categoria.CONGRESSO, Categoria.SEMINARIO, Categoria.WORKSHOP, Categoria.OUTRO);
        } else {
            campoCategoria.getItems().setAll(Categoria.PROVA, Categoria.TRABALHO, Categoria.PRAZO, Categoria.REUNIAO, Categoria.LEMBRETE, Categoria.OUTRO);
        }

        campoCategoria.setValue(null);
    }

    // ==========================================
    // AUXILIARES
    // ==========================================

    // Método responsável por adicionar mensagem.
    private void adicionarMensagem(VBox destino, String mensagem) {
        Label label = new Label(mensagem);

        label.setWrapText(true);

        label.setStyle("-fx-text-fill: #68758A;" + "-fx-font-size: 12px;" + "-fx-padding: 8;");

        destino.getChildren().add(label);
    }

    // Método responsável por mostrar alerta.
    private void mostrarAlerta(Alert.AlertType tipo, String titulo, String mensagem) {
        Alert alerta = new Alert(tipo);

        alerta.setTitle(titulo);
        alerta.setHeaderText(null);
        alerta.setContentText(mensagem);

        alerta.showAndWait();
    }

    // ==========================================
    // NAVEGAÇÃO
    // ==========================================

    @FXML
    private void voltarAcademico() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/TelaAcademica.fxml"));

            Parent root = loader.load();

            Stage stage = (Stage) gradeCalendario.getScene().getWindow();

            stage.setScene(new Scene(root, 390, 844));
            stage.setTitle("CampusHub - Acadêmico");

            stage.show();
        } catch (IOException e) {
            mostrarAlerta(Alert.AlertType.ERROR, "Erro de navegação", "Não foi possível voltar à tela acadêmica.");
        }
    }
}
