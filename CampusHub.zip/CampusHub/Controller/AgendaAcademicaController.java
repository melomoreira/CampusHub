// Define o pacote Controller, que organiza as classes do projeto.
package Controller;

// Importa as classes e bibliotecas utilizadas neste arquivo.
import Model.CompromissoAcademico;
import Model.CompromissoAcademico.Categoria;
import Model.CompromissoAcademico.Status;
import Model.CompromissoAcademico.Tipo;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

// Classe responsável por controlar as ações relacionadas a agenda acadêmica.
public class AgendaAcademicaController {
    // Atributos
    private static final AgendaAcademicaController instancia = new AgendaAcademicaController();

    private final List<CompromissoAcademico> compromissos = new ArrayList<>();

    // Construtores
    private AgendaAcademicaController() {
    }

    // Método utilizado para consultar instancia.
    public static AgendaAcademicaController getInstancia() {
        return instancia;
    }

    // ==========================================
    // CADASTRO DE COMPROMISSO PESSOAL
    // ==========================================

    // Método responsável por cadastrar compromisso pessoal.
    public CompromissoAcademico cadastrarCompromissoPessoal(String email, String nome, String titulo, String descricao, LocalDateTime inicio, LocalDateTime fim, String local, Categoria categoria) {
        validarDados(email, nome, titulo, inicio, fim, categoria);

        CompromissoAcademico compromisso = new CompromissoAcademico(email, nome, Tipo.PESSOAL, titulo, descricao, inicio, fim, local, categoria);

        compromissos.add(compromisso);

        return compromisso;
    }

    // ==========================================
    // SUGESTÃO DE EVENTO ACADÊMICO
    // ==========================================

    // Método responsável por sugerir evento academico.
    public CompromissoAcademico sugerirEventoAcademico(String email, String nome, String titulo, String descricao, LocalDateTime inicio, LocalDateTime fim, String local, Categoria categoria) {
        validarDados(email, nome, titulo, inicio, fim, categoria);

        CompromissoAcademico evento = new CompromissoAcademico(email, nome, Tipo.EVENTO_ACADEMICO, titulo, descricao, inicio, fim, local, categoria);

        compromissos.add(evento);

        return evento;
    }

    // ==========================================
    // CONSULTAS
    // ==========================================

    // Compromissos pessoais do usuário e eventos acadêmicos aprovados.
    public List<CompromissoAcademico> listarAgendaUsuario(String email) {
        List<CompromissoAcademico> resultado = new ArrayList<>();

        for (CompromissoAcademico c : compromissos) {
            boolean compromissoPessoal = c.getTipo() == Tipo.PESSOAL && c.getCriadorEmail().equalsIgnoreCase(email);

            boolean eventoPublico = c.getTipo() == Tipo.EVENTO_ACADEMICO && c.getStatus() == Status.APROVADO;

            if (compromissoPessoal || eventoPublico) {
                resultado.add(c);
            }
        }

        resultado.sort(Comparator.comparing(CompromissoAcademico::getInicio));

        return resultado;
    }

    // Sugestões que aguardam aprovação.
    public List<CompromissoAcademico> listarSugestoesPendentes() {
        List<CompromissoAcademico> resultado = new ArrayList<>();

        for (CompromissoAcademico c : compromissos) {
            if (c.getTipo() == Tipo.EVENTO_ACADEMICO && c.getStatus() == Status.PENDENTE) {

                resultado.add(c);
            }
        }

        resultado.sort(Comparator.comparing(CompromissoAcademico::getDataCriacao));

        return resultado;
    }

    // Sugestões feitas pelo próprio usuário.
    public List<CompromissoAcademico> listarMinhasSugestoes(String email) {
        List<CompromissoAcademico> resultado = new ArrayList<>();

        for (CompromissoAcademico c : compromissos) {
            if (c.getTipo() == Tipo.EVENTO_ACADEMICO && c.getCriadorEmail().equalsIgnoreCase(email)) {

                resultado.add(c);
            }
        }

        resultado.sort(Comparator.comparing(CompromissoAcademico::getDataCriacao).reversed());

        return resultado;
    }

    // Método utilizado para consultar buscar por id.
    public CompromissoAcademico buscarPorId(String id) {
        for (CompromissoAcademico c : compromissos) {
            if (c.getId().equals(id)) {
                return c;
            }
        }

        return null;
    }

    // ==========================================
    // EDIÇÃO
    // ==========================================

    // Método responsável por editar.
    public boolean editar(String id, String email, String titulo, String descricao, LocalDateTime inicio, LocalDateTime fim, String local, Categoria categoria) {
        CompromissoAcademico c = buscarPorId(id);

        if (c == null || !ehCriador(c, email)) {
            return false;
        }

        validarDados(email, c.getCriadorNome(), titulo, inicio, fim, categoria);

        c.atualizarDados(titulo, descricao, inicio, fim, local, categoria);

        // Evento público editado precisa ser aprovado novamente.
        if (c.getTipo() == Tipo.EVENTO_ACADEMICO) {
            c.voltarParaPendente();
        }

        return true;
    }

    // ==========================================
    // APROVAÇÃO E REJEIÇÃO
    // ==========================================

    // Método responsável por aprovar evento.
    public boolean aprovarEvento(String id, String emailAprovador) {
        CompromissoAcademico c = buscarPorId(id);

        if (c == null || c.getTipo() != Tipo.EVENTO_ACADEMICO || c.getStatus() != Status.PENDENTE) {

            return false;
        }

        if (emailAprovador == null || emailAprovador.isBlank()) {
            return false;
        }

        c.aprovar(emailAprovador);

        return true;
    }

    // Método responsável por rejeitar evento.
    public boolean rejeitarEvento(String id) {
        CompromissoAcademico c = buscarPorId(id);

        if (c == null || c.getTipo() != Tipo.EVENTO_ACADEMICO || c.getStatus() != Status.PENDENTE) {

            return false;
        }

        c.rejeitar();

        return true;
    }

    // ==========================================
    // EXCLUSÃO
    // ==========================================

    // Método utilizado para remover excluir.
    public boolean excluir(String id, String email) {
        CompromissoAcademico c = buscarPorId(id);

        if (c == null || !ehCriador(c, email)) {
            return false;
        }

        return compromissos.remove(c);
    }

    // ==========================================
    // VALIDAÇÕES
    // ==========================================

    // Método responsável por eh criador.
    private boolean ehCriador(CompromissoAcademico c, String email) {
        return email != null && c.getCriadorEmail().equalsIgnoreCase(email);
    }

    // Método utilizado para verificar validar dados.
    private void validarDados(String email, String nome, String titulo, LocalDateTime inicio, LocalDateTime fim, Categoria categoria) {
        if (email == null || email.isBlank() || nome == null || nome.isBlank() || titulo == null || titulo.isBlank() || inicio == null || categoria == null) {
            throw new IllegalArgumentException("Preencha os campos obrigatórios.");
        }

        if (fim != null && fim.isBefore(inicio)) {
            throw new IllegalArgumentException("O término não pode ser anterior ao início.");
        }
    }
}
