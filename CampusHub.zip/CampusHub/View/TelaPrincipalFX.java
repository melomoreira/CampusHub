// Define o pacote View, que organiza as classes do projeto.
package View;

// Importa as classes e bibliotecas utilizadas neste arquivo.
import Model.BancoDados;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.image.Image;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

// Classe responsável por iniciar e exibir a aplicação.
public class TelaPrincipalFX extends Application {
    @Override
    public void start(Stage stage) throws Exception {
        // Inicializa o banco de dados
        BancoDados.inicializar();

        FXMLLoader loader = new FXMLLoader(getClass().getResource("TelaLogin.fxml"));

        Parent tela = loader.load();

        StackPane fundo = new StackPane(tela);
        fundo.setStyle("-fx-background-color: #E9EDF5;");

        Scene cena = new Scene(fundo, 390, 844);

        stage.setTitle("CampusHub - Login");
        stage.getIcons().add(new Image(getClass().getResourceAsStream("/imagens/CampusHub_Logo.png")));

        stage.setScene(cena);
        stage.setResizable(false);
        stage.show();
    }

    // Método Main
    public static void main(String[] args) {
        launch(args);
    }
}
