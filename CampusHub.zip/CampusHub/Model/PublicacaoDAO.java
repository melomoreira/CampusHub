// Define o pacote Model, que organiza as classes do projeto.
package Model;

// Importa as classes e bibliotecas utilizadas neste arquivo.
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

// Classe responsável pelo acesso aos dados de publicação.
public class PublicacaoDAO {
    // Salva uma publicação.
    public void salvar(Publicacao publicacao) throws SQLException {
        String sql = """
            INSERT INTO publicacao (
                id, autor_email, autor_nome, titulo,
                conteudo, data_criacao, data_atualizacao
            ) VALUES (?, ?, ?, ?, ?, ?, ?);""";

        try (Connection conexao = ConexaoBanco.conectar(); PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setString(1, publicacao.getId());
            stmt.setString(2, publicacao.getAutorEmail());
            stmt.setString(3, publicacao.getAutorNome());
            stmt.setString(4, publicacao.getTitulo());
            stmt.setString(5, publicacao.getConteudo());
            stmt.setString(6, publicacao.getDataCriacao().toString());
            stmt.setString(7, publicacao.getDataAtualizacao().toString());

            stmt.executeUpdate();
        }
    }

    // Lista todas as publicações.
    public List<Publicacao> listarTodas() throws SQLException {
        List<Publicacao> publicacoes = new ArrayList<>();

        String sql = """
            SELECT id, autor_email, autor_nome, titulo,
                   conteudo, data_criacao, data_atualizacao
            FROM publicacao
            ORDER BY data_criacao DESC;""";

        try (Connection conexao = ConexaoBanco.conectar(); PreparedStatement stmt = conexao.prepareStatement(sql); ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                publicacoes.add(mapearPublicacao(rs));
            }
        }

        return publicacoes;
    }

    // Busca uma publicação pelo ID.
    public Publicacao buscarPorId(String id) throws SQLException {
        String sql = """
            SELECT id, autor_email, autor_nome, titulo,
                   conteudo, data_criacao, data_atualizacao
            FROM publicacao
            WHERE id = ?;""";

        try (Connection conexao = ConexaoBanco.conectar(); PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setString(1, id);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapearPublicacao(rs);
                }
            }
        }

        return null;
    }

    // Atualiza uma publicação.
    public boolean atualizar(Publicacao publicacao) throws SQLException {
        String sql = """
            UPDATE publicacao
            SET titulo = ?,
                conteudo = ?,
                data_atualizacao = ?
            WHERE id = ?;""";

        try (Connection conexao = ConexaoBanco.conectar(); PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setString(1, publicacao.getTitulo());
            stmt.setString(2, publicacao.getConteudo());
            stmt.setString(3, publicacao.getDataAtualizacao().toString());
            stmt.setString(4, publicacao.getId());

            return stmt.executeUpdate() > 0;
        }
    }

    // Exclui uma publicação pelo ID.
    public boolean excluir(String id) throws SQLException {
        String sql = "DELETE FROM publicacao WHERE id = ?;";

        try (Connection conexao = ConexaoBanco.conectar(); PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setString(1, id);

            return stmt.executeUpdate() > 0;
        }
    }

    // Converte um registro do banco em objeto Publicacao.
    private Publicacao mapearPublicacao(ResultSet rs) throws SQLException {
        return new Publicacao(
            rs.getString("id"),
            rs.getString("autor_email"),
            rs.getString("autor_nome"),
            rs.getString("titulo"),
            rs.getString("conteudo"),
            LocalDateTime.parse(rs.getString("data_criacao")),
            LocalDateTime.parse(rs.getString("data_atualizacao"))
        );
    }
}
