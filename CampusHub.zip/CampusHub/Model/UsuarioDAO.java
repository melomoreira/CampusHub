// Define o pacote Model, que organiza as classes do projeto.
package Model;

// Importa as classes e bibliotecas utilizadas neste arquivo.
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

// Classe responsável pelo acesso aos dados de usuário.
public class UsuarioDAO {
    // Método responsável por salvar.
    public void salvar(Usuario usuario) throws SQLException {
        String email = normalizarEmail(usuario.getEmail());

        if (usuario == null || email == null ||
            usuario.getSenha() == null || usuario.getSenha().isEmpty()) {
            throw new IllegalArgumentException("Dados obrigatórios do usuário ausentes.");
        }

        String salt = SegurancaSenha.gerarSalt();
        String hash = SegurancaSenha.gerarHash(usuario.getSenha(), salt);

        String sql = """
            INSERT INTO usuario
            (email, nome, senha_hash, senha_salt, universidade, curso, foto_perfil_path)
            VALUES (?, ?, ?, ?, ?, ?, ?);""";

        try (Connection conexao = ConexaoBanco.conectar(); PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setString(1, email);
            stmt.setString(2, usuario.getNome());
            stmt.setString(3, hash);
            stmt.setString(4, salt);
            stmt.setString(5, usuario.getUniversidade());
            stmt.setString(6, usuario.getCurso());
            stmt.setString(7, usuario.getFotoPerfilPath());

            stmt.executeUpdate();

            salvarInteresses(conexao, email, usuario.getInteresses());
        }
    }

    // Método responsável por salvar interesses.
    private void salvarInteresses(Connection conexao, String email, List<String> interesses) throws SQLException {
        String sql = """
            INSERT INTO usuario_interesse (usuario_email, interesse)
            VALUES (?, ?);""";

        if (interesses == null || interesses.isEmpty()) {
            return;
        }

        try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
            for (String interesse : interesses) {
                if (interesse != null && !interesse.trim().isEmpty()) {
                    stmt.setString(1, email);
                    stmt.setString(2, interesse.trim());
                    stmt.addBatch();
                }
            }

            stmt.executeBatch();
        }
    }

    // Método responsável por autenticar.
    public Usuario autenticar(String email, String senha) throws SQLException {
        if (email == null || senha == null) {
            return null;
        }

        String sql = """
            SELECT email, nome, senha_hash, senha_salt,
                   universidade, curso, foto_perfil_path
            FROM usuario
            WHERE email = ? COLLATE NOCASE;""";

        try (Connection conexao = ConexaoBanco.conectar(); PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setString(1, normalizarEmail(email));

            try (ResultSet rs = stmt.executeQuery()) {
                if (!rs.next()) {
                    return null;
                }

                boolean senhaCorreta = SegurancaSenha.verificarSenha(senha, rs.getString("senha_hash"), rs.getString("senha_salt"));

                if (!senhaCorreta) {
                    return null;
                }

                return mapearUsuario(conexao, rs);
            }
        }
    }

    // Método utilizado para consultar buscar por email.
    public Usuario buscarPorEmail(String email) throws SQLException {
        if (email == null) {
            return null;
        }

        String sql = """
            SELECT email, nome, universidade, curso, foto_perfil_path
            FROM usuario
            WHERE email = ? COLLATE NOCASE;""";

        try (Connection conexao = ConexaoBanco.conectar(); PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setString(1, normalizarEmail(email));

            try (ResultSet rs = stmt.executeQuery()) {
                if (!rs.next()) {
                    return null;
                }

                return mapearUsuario(conexao, rs);
            }
        }
    }

    // Método utilizado para consultar listar todos.
    public ArrayList<Usuario> listarTodos() throws SQLException {
        ArrayList<Usuario> usuarios = new ArrayList<>();

        String sql = """
            SELECT email, nome, universidade, curso, foto_perfil_path
            FROM usuario
            ORDER BY nome COLLATE NOCASE;""";

        try (Connection conexao = ConexaoBanco.conectar(); PreparedStatement stmt = conexao.prepareStatement(sql); ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                usuarios.add(mapearUsuario(conexao, rs));
            }
        }

        return usuarios;
    }

    // Método utilizado para consultar listar universidades.
    public ArrayList<String> listarUniversidades() throws SQLException {
        ArrayList<String> universidades = new ArrayList<>();

        String sql = """
            SELECT DISTINCT universidade
            FROM usuario
            WHERE universidade IS NOT NULL AND TRIM(universidade) <> ''
            ORDER BY universidade COLLATE NOCASE;""";

        try (Connection conexao = ConexaoBanco.conectar(); PreparedStatement stmt = conexao.prepareStatement(sql); ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                universidades.add(rs.getString("universidade"));
            }
        }

        return universidades;
    }

    // Método utilizado para atualizar atualizar.
    public boolean atualizar(String email, String novoNome, String novaUniversidade, String novoCurso) throws SQLException {
        String sql = """
            UPDATE usuario
            SET nome = ?, universidade = ?, curso = ?
            WHERE email = ? COLLATE NOCASE;""";

        try (Connection conexao = ConexaoBanco.conectar(); PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setString(1, novoNome);
            stmt.setString(2, novaUniversidade);
            stmt.setString(3, novoCurso);
            stmt.setString(4, normalizarEmail(email));

            return stmt.executeUpdate() > 0;
        }
    }

    // Método utilizado para remover excluir.
    public boolean excluir(String email) throws SQLException {
        String sql = "DELETE FROM usuario WHERE email = ? COLLATE NOCASE;";

        try (Connection conexao = ConexaoBanco.conectar(); PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setString(1, normalizarEmail(email));

            return stmt.executeUpdate() > 0;
        }
    }

    // Método utilizado para atualizar atualizar perfil.
    public boolean atualizarPerfil(String emailAtual, Usuario usuario) throws SQLException {
        if (emailAtual == null || usuario == null || usuario.getEmail() == null) {
            return false;
        }

        String sqlExcluirInteresses = "DELETE FROM usuario_interesse WHERE usuario_email = ?;";

        String sqlAtualizarUsuario = """
            UPDATE usuario
            SET email = ?,
                nome = ?,
                universidade = ?,
                curso = ?,
                foto_perfil_path = ?
            WHERE email = ? COLLATE NOCASE;""";

        try (Connection conexao = ConexaoBanco.conectar()) {
            conexao.setAutoCommit(false);

            try {
                try (PreparedStatement stmt = conexao.prepareStatement(sqlExcluirInteresses)) {
                    stmt.setString(1, emailAtual.trim());
                    stmt.executeUpdate();
                }

                try (PreparedStatement stmt = conexao.prepareStatement(sqlAtualizarUsuario)) {
                    stmt.setString(1, usuario.getEmail().trim());
                    stmt.setString(2, usuario.getNome());
                    stmt.setString(3, usuario.getUniversidade());
                    stmt.setString(4, usuario.getCurso());
                    stmt.setString(5, usuario.getFotoPerfilPath());
                    stmt.setString(6, emailAtual.trim());

                    int linhas = stmt.executeUpdate();

                    if (linhas == 0) {
                        conexao.rollback();
                        return false;
                    }
                }

                salvarInteresses(conexao, usuario.getEmail().trim(), usuario.getInteresses());

                conexao.commit();
                return true;
            } catch (SQLException e) {
                conexao.rollback();
                throw e;
            } finally {
                conexao.setAutoCommit(true);
            }
        }
    }

    // Método responsável por mapear usuario.
    private Usuario mapearUsuario(Connection conexao, ResultSet rs) throws SQLException {
        String email = rs.getString("email");

        ArrayList<String> interesses = new ArrayList<>();

        String sqlInteresses = """
            SELECT interesse
            FROM usuario_interesse
            WHERE usuario_email = ?
            ORDER BY interesse COLLATE NOCASE;""";

        try (PreparedStatement stmt = conexao.prepareStatement(sqlInteresses)) {
            stmt.setString(1, email);

            try (ResultSet rsInteresses = stmt.executeQuery()) {
                while (rsInteresses.next()) {
                    interesses.add(rsInteresses.getString("interesse"));
                }
            }
        }

        Usuario usuario = new Usuario(rs.getString("nome"), email, null, rs.getString("universidade"), rs.getString("curso"), interesses);

        usuario.setFotoPerfilPath(rs.getString("foto_perfil_path"));

        return usuario;
    }

    // Método responsável por normalizar email.
    private String normalizarEmail(String email) {
        return email == null ? null : email.trim();
    }
}
