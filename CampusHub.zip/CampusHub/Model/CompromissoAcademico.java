// Define o pacote Model, que organiza as classes do projeto.
package Model;

// Importa as classes e bibliotecas utilizadas neste arquivo.
import java.time.LocalDateTime;
import java.util.UUID;

// Classe que representa os dados e características de compromisso academico.
public class CompromissoAcademico {
    public enum Tipo {
        PESSOAL,
        EVENTO_ACADEMICO
    }

    public enum Status {
        NAO_APLICAVEL,
        PENDENTE,
        APROVADO,
        REJEITADO
    }

    public enum Categoria {
        PROVA,
        TRABALHO,
        PRAZO,
        REUNIAO,
        LEMBRETE,
        PALESTRA,
        CONGRESSO,
        SEMINARIO,
        WORKSHOP,
        OUTRO
    }

    // Atributos
    private final String id;
    // Atributo utilizado para armazenar criador email.
    private final String criadorEmail;
    // Atributo utilizado para armazenar criador nome.
    private final String criadorNome;
    // Atributo utilizado para armazenar tipo.
    private final Tipo tipo;
    // Atributo utilizado para armazenar data criacao.
    private final LocalDateTime dataCriacao;

    // Atributo utilizado para armazenar titulo.
    private String titulo;
    // Atributo utilizado para armazenar descricao.
    private String descricao;
    // Atributo utilizado para armazenar inicio.
    private LocalDateTime inicio;
    // Atributo utilizado para armazenar fim.
    private LocalDateTime fim;
    // Atributo utilizado para armazenar local.
    private String local;
    // Atributo utilizado para armazenar categoria.
    private Categoria categoria;
    // Atributo utilizado para armazenar status.
    private Status status;
    // Atributo utilizado para armazenar aprovador email.
    private String aprovadorEmail;
    // Atributo utilizado para armazenar data atualizacao.
    private LocalDateTime dataAtualizacao;

    // Construtor
    public CompromissoAcademico(String criadorEmail, String criadorNome, Tipo tipo, String titulo, String descricao, LocalDateTime inicio, LocalDateTime fim, String local, Categoria categoria) {
        this.id = UUID.randomUUID().toString();

        this.criadorEmail = criadorEmail;
        this.criadorNome = criadorNome;
        this.tipo = tipo;

        this.titulo = titulo;
        this.descricao = descricao;
        this.inicio = inicio;
        this.fim = fim;
        this.local = local;
        this.categoria = categoria;

        this.dataCriacao = LocalDateTime.now();
        this.dataAtualizacao = LocalDateTime.now();

        if (tipo == Tipo.EVENTO_ACADEMICO) {
            this.status = Status.PENDENTE;
        } else {
            this.status = Status.NAO_APLICAVEL;
        }
    }

    // Métodos Getters
    public String getId() {
        return id;
    }

    // Método utilizado para consultar criador email.
    public String getCriadorEmail() {
        return criadorEmail;
    }

    // Método utilizado para consultar criador nome.
    public String getCriadorNome() {
        return criadorNome;
    }

    // Método utilizado para consultar tipo.
    public Tipo getTipo() {
        return tipo;
    }

    // Método utilizado para consultar titulo.
    public String getTitulo() {
        return titulo;
    }

    // Método utilizado para consultar descricao.
    public String getDescricao() {
        return descricao;
    }

    // Método utilizado para consultar inicio.
    public LocalDateTime getInicio() {
        return inicio;
    }

    // Método utilizado para consultar fim.
    public LocalDateTime getFim() {
        return fim;
    }

    // Método utilizado para consultar local.
    public String getLocal() {
        return local;
    }

    // Método utilizado para consultar categoria.
    public Categoria getCategoria() {
        return categoria;
    }

    // Método utilizado para consultar status.
    public Status getStatus() {
        return status;
    }

    // Método utilizado para consultar aprovador email.
    public String getAprovadorEmail() {
        return aprovadorEmail;
    }

    // Método utilizado para consultar data criacao.
    public LocalDateTime getDataCriacao() {
        return dataCriacao;
    }

    // Método utilizado para consultar data atualizacao.
    public LocalDateTime getDataAtualizacao() {
        return dataAtualizacao;
    }

    // Métodos
    public void atualizarDados(String titulo, String descricao, LocalDateTime inicio, LocalDateTime fim, String local, Categoria categoria) {
        this.titulo = titulo;
        this.descricao = descricao;
        this.inicio = inicio;
        this.fim = fim;
        this.local = local;
        this.categoria = categoria;

        this.dataAtualizacao = LocalDateTime.now();
    }

    // Método responsável por aprovar.
    public void aprovar(String aprovadorEmail) {
        this.status = Status.APROVADO;
        this.aprovadorEmail = aprovadorEmail;
        this.dataAtualizacao = LocalDateTime.now();
    }

    // Método responsável por rejeitar.
    public void rejeitar() {
        this.status = Status.REJEITADO;
        this.aprovadorEmail = null;
        this.dataAtualizacao = LocalDateTime.now();
    }

    // Método responsável por voltar para pendente.
    public void voltarParaPendente() {
        if (tipo == Tipo.EVENTO_ACADEMICO) {
            this.status = Status.PENDENTE;
            this.aprovadorEmail = null;
            this.dataAtualizacao = LocalDateTime.now();
        }
    }
}
