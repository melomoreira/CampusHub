// Define o pacote Model, que organiza as classes do projeto.
package Model;

// Classe que representa os dados e características de campus.
public class Campus {
    // Identificação do campus
    private String id;

    // Informações do campus
    private String universidade;
    // Atributo utilizado para armazenar nome.
    private String nome;
    // Atributo utilizado para armazenar descricao.
    private String descricao;

    // Caminho da imagem do mapa do campus
    private String caminhoImagem;

    // Construtor com as informações do campus
    public Campus(String id, String universidade, String nome, String descricao, String caminhoImagem) {
        this.id = id;
        this.universidade = universidade;
        this.nome = nome;
        this.descricao = descricao;
        this.caminhoImagem = caminhoImagem;
    }

    // Métodos getters: utilizados para consultar os atributos
    public String getId() {
        return id;
    }

    // Método utilizado para consultar universidade.
    public String getUniversidade() {
        return universidade;
    }

    // Método utilizado para consultar nome.
    public String getNome() {
        return nome;
    }

    // Método utilizado para consultar descricao.
    public String getDescricao() {
        return descricao;
    }

    // Método utilizado para consultar caminho imagem.
    public String getCaminhoImagem() {
        return caminhoImagem;
    }

    // Métodos setters: utilizados para modificar os atributos
    public void setId(String id) {
        this.id = id;
    }

    // Método utilizado para atualizar universidade.
    public void setUniversidade(String universidade) {
        this.universidade = universidade;
    }

    // Método utilizado para atualizar nome.
    public void setNome(String nome) {
        this.nome = nome;
    }

    // Método utilizado para atualizar descricao.
    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    // Método utilizado para atualizar caminho imagem.
    public void setCaminhoImagem(String caminhoImagem) {
        this.caminhoImagem = caminhoImagem;
    }
}
