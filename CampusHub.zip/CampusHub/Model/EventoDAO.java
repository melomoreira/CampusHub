// Define o pacote Model, que organiza as classes do projeto.
package Model;

// Importa as classes e bibliotecas utilizadas neste arquivo.
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

// Classe responsável pelo acesso aos dados de evento.
public class EventoDAO {
    // Atributos
    private final UsuarioDAO usuarioDAO = new UsuarioDAO();

    // CREATE: salvar evento e participantes
    public boolean salvar(Evento evento) {
        if (evento == null) {
            return false;
        }

        String sql = "INSERT INTO evento "
                   + "(id, titulo, data, horario, local, descricao, organizador_email) "
                   + "VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection conexao = ConexaoBanco.conectar()) {
            conexao.setAutoCommit(false);

            try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
                stmt.setString(1, evento.getId());
                stmt.setString(2, evento.getTitulo());
                stmt.setString(3, evento.getData());
                stmt.setString(4, evento.getHorario());
                stmt.setString(5, evento.getLocal());
                stmt.setString(6, evento.getDescricao());

                if (evento.getOrganizador() != null) {
                    stmt.setString(7, evento.getOrganizador().getEmail());
                } else {
                    stmt.setNull(7, java.sql.Types.VARCHAR);
                }

                stmt.executeUpdate();
            }

            // Salvar participantes
            salvarParticipantes(conexao, evento);

            conexao.commit();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Salvar participantes dentro da mesma transação
    private void salvarParticipantes(Connection conexao, Evento evento) throws SQLException {
        String sql = "INSERT INTO evento_participante "
                   + "(evento_id, usuario_email) VALUES (?, ?)";

        try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
            for (Usuario usuario : evento.getParticipantes()) {
                if (usuario == null || usuario.getEmail() == null) {
                    continue;
                }

                stmt.setString(1, evento.getId());
                stmt.setString(2, usuario.getEmail());
                stmt.addBatch();
            }

            stmt.executeBatch();
        }
    }

    // READ: listar todos os eventos
    public ArrayList<Evento> listarTodos() {
        ArrayList<Evento> lista = new ArrayList<>();

        String sql = "SELECT * FROM evento ORDER BY data, horario";

        try (Connection conexao = ConexaoBanco.conectar(); PreparedStatement stmt = conexao.prepareStatement(sql); ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Evento evento = mapearEvento(rs);
                lista.add(evento);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return lista;
    }

    // READ: buscar evento pelo ID
    public Evento buscarPorId(String id) {
        if (id == null) {
            return null;
        }

        String sql = "SELECT * FROM evento WHERE id = ?";

        try (Connection conexao = ConexaoBanco.conectar(); PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setString(1, id);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapearEvento(rs);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

    // UPDATE: atualizar evento
    public boolean atualizar(Evento evento) {
        if (evento == null) {
            return false;
        }

        String sql = "UPDATE evento SET "
                   + "titulo = ?, data = ?, horario = ?, "
                   + "local = ?, descricao = ?, organizador_email = ? "
                   + "WHERE id = ?";

        try (Connection conexao = ConexaoBanco.conectar(); PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setString(1, evento.getTitulo());
            stmt.setString(2, evento.getData());
            stmt.setString(3, evento.getHorario());
            stmt.setString(4, evento.getLocal());
            stmt.setString(5, evento.getDescricao());

            if (evento.getOrganizador() != null) {
                stmt.setString(6, evento.getOrganizador().getEmail());
            } else {
                stmt.setNull(6, java.sql.Types.VARCHAR);
            }

            stmt.setString(7, evento.getId());

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // DELETE: excluir evento
    public boolean excluir(String id) {
        if (id == null) {
            return false;
        }

        String sql = "DELETE FROM evento WHERE id = ?";

        try (Connection conexao = ConexaoBanco.conectar(); PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setString(1, id);

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Inscrever usuário em evento
    public boolean adicionarParticipante(String eventoId, Usuario usuario) {
        if (eventoId == null || usuario == null || usuario.getEmail() == null) {
            return false;
        }

        String sql = "INSERT INTO evento_participante "
                   + "(evento_id, usuario_email) VALUES (?, ?)";

        try (Connection conexao = ConexaoBanco.conectar(); PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setString(1, eventoId);
            stmt.setString(2, usuario.getEmail());

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Remover inscrição
    public boolean removerParticipante(String eventoId, Usuario usuario) {
        if (eventoId == null || usuario == null || usuario.getEmail() == null) {
            return false;
        }

        String sql = "DELETE FROM evento_participante "
                   + "WHERE evento_id = ? AND usuario_email = ?";

        try (Connection conexao = ConexaoBanco.conectar(); PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setString(1, eventoId);
            stmt.setString(2, usuario.getEmail());

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Verificar se usuário já está inscrito
    public boolean usuarioParticipa(String eventoId, Usuario usuario) {
        if (eventoId == null || usuario == null || usuario.getEmail() == null) {
            return false;
        }

        String sql = "SELECT 1 FROM evento_participante "
                   + "WHERE evento_id = ? AND usuario_email = ?";

        try (Connection conexao = ConexaoBanco.conectar(); PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setString(1, eventoId);
            stmt.setString(2, usuario.getEmail());

            try (ResultSet rs = stmt.executeQuery()) {
                return rs.next();
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Converter registro do banco em objeto Evento
    private Evento mapearEvento(ResultSet rs) throws SQLException {
        String organizadorEmail = rs.getString("organizador_email");
        Usuario organizador = null;

        if (organizadorEmail != null) {
            organizador = usuarioDAO.buscarPorEmail(organizadorEmail);
        }

        Evento evento = new Evento(
            rs.getString("id"),
            rs.getString("titulo"),
            rs.getString("data"),
            rs.getString("horario"),
            rs.getString("local"),
            rs.getString("descricao"),
            organizador
        );

        // Recuperar participantes
        String sqlParticipantes = "SELECT usuario_email FROM evento_participante WHERE evento_id = ?";

        try (Connection conexao = ConexaoBanco.conectar(); PreparedStatement stmt = conexao.prepareStatement(sqlParticipantes)) {
            stmt.setString(1, evento.getId());

            try (ResultSet rsParticipantes = stmt.executeQuery()) {
                while (rsParticipantes.next()) {
                    String email = rsParticipantes.getString("usuario_email");
                    Usuario usuario = usuarioDAO.buscarPorEmail(email);

                    if (usuario != null) {
                        evento.adicionarParticipante(usuario);
                    }
                }
            }
        }

        return evento;
    }
}
