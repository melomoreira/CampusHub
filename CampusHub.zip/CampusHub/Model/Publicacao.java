// Define o pacote Model, que organiza as classes do projeto.
package Model;

// Importa as classes e bibliotecas utilizadas neste arquivo.
import java.time.LocalDateTime;
import java.util.UUID;

// Classe que representa os dados e características de publicação.
public class Publicacao {
    // Atributos
    private final String id;
    // Atributo utilizado para armazenar autor email.
    private final String autorEmail;
    // Atributo utilizado para armazenar autor nome.
    private final String autorNome;
    // Atributo utilizado para armazenar data criacao.
    private final LocalDateTime dataCriacao;

    // Atributo utilizado para armazenar titulo.
    private String titulo;
    // Atributo utilizado para armazenar conteudo.
    private String conteudo;
    // Atributo utilizado para armazenar data atualizacao.
    private LocalDateTime dataAtualizacao;

    // Construtor
    public Publicacao(String autorEmail, String autorNome, String titulo, String conteudo) {
        this.id = UUID.randomUUID().toString();
        this.autorEmail = autorEmail;
        this.autorNome = autorNome;
        this.titulo = titulo;
        this.conteudo = conteudo;
        this.dataCriacao = LocalDateTime.now();
        this.dataAtualizacao = dataCriacao;
    }

    // Construtor utilizado para recuperar uma publicação do banco.
    public Publicacao(String id, String autorEmail, String autorNome, String titulo, String conteudo, LocalDateTime dataCriacao, LocalDateTime dataAtualizacao) {
        this.id = id;
        this.autorEmail = autorEmail;
        this.autorNome = autorNome;
        this.titulo = titulo;
        this.conteudo = conteudo;
        this.dataCriacao = dataCriacao;
        this.dataAtualizacao = dataAtualizacao;
    }

    // Métodos Getters
    public String getId() {
        return id;
    }

    // Método utilizado para consultar autor email.
    public String getAutorEmail() {
        return autorEmail;
    }

    // Método utilizado para consultar autor nome.
    public String getAutorNome() {
        return autorNome;
    }

    // Método utilizado para consultar titulo.
    public String getTitulo() {
        return titulo;
    }

    // Método utilizado para consultar conteudo.
    public String getConteudo() {
        return conteudo;
    }

    // Método utilizado para consultar data criacao.
    public LocalDateTime getDataCriacao() {
        return dataCriacao;
    }

    // Método utilizado para consultar data atualizacao.
    public LocalDateTime getDataAtualizacao() {
        return dataAtualizacao;
    }

    // Métodos Setters
    public void setTitulo(String titulo) {
        this.titulo = titulo;
        this.dataAtualizacao = LocalDateTime.now();
    }

    // Método utilizado para atualizar conteudo.
    public void setConteudo(String conteudo) {
        this.conteudo = conteudo;
        this.dataAtualizacao = LocalDateTime.now();
    }
}
