// Define o pacote Model, que organiza as classes do projeto.
package Model;

// Importa as classes e bibliotecas utilizadas neste arquivo.
import java.util.ArrayList;
import java.util.List;

// Classe que representa os dados e características de usuário.
public class Usuario {
    // Atributos do usuário
    private String nome;
    // Atributo utilizado para armazenar e-mail.
    private String email;
    // Atributo utilizado para armazenar senha.
    private String senha;
    // Atributo utilizado para armazenar universidade.
    private String universidade;
    // Atributo utilizado para armazenar curso.
    private String curso;
    // Atributo utilizado para armazenar interesses.
    private List<String> interesses;
    // Atributo utilizado para armazenar caminho da foto de perfil.
    private String fotoPerfilPath;

    // Construtor com informações básicas do usuário
    public Usuario(String nome, String universidade, String curso, List<String> interesses) {
        this.nome = nome;
        this.universidade = universidade;
        this.curso = curso;
        this.interesses = interesses == null ? new ArrayList<>() : new ArrayList<>(interesses);
    }

    // Construtor com todas as informações principais do usuário
    public Usuario(String nome, String email, String senha, String universidade, String curso, List<String> interesses) {
        this.nome = nome;
        this.email = email;
        this.senha = senha;
        this.universidade = universidade;
        this.curso = curso;
        this.interesses = interesses == null ? new ArrayList<>() : new ArrayList<>(interesses);
    }

    // Métodos getters: utilizados para consultar os atributos
    public String getNome() {
        return nome;
    }

    // Método utilizado para consultar e-mail.
    public String getEmail() {
        return email;
    }

    // Método utilizado para consultar senha.
    public String getSenha() {
        return senha;
    }

    // Método utilizado para consultar universidade.
    public String getUniversidade() {
        return universidade;
    }

    // Método utilizado para consultar curso.
    public String getCurso() {
        return curso;
    }

    // Método utilizado para consultar interesses.
    public List<String> getInteresses() {
        return new ArrayList<>(interesses);
    }

    // Método utilizado para consultar caminho da foto de perfil.
    public String getFotoPerfilPath() {
        return fotoPerfilPath;
    }

    // Métodos setters: utilizados para modificar os atributos
    public void setNome(String nome) {
        this.nome = nome;
    }

    // Método utilizado para atualizar e-mail.
    public void setEmail(String email) {
        this.email = email;
    }

    // Método utilizado para atualizar senha.
    public void setSenha(String senha) {
        this.senha = senha;
    }

    // Método utilizado para atualizar universidade.
    public void setUniversidade(String universidade) {
        this.universidade = universidade;
    }

    // Método utilizado para atualizar curso.
    public void setCurso(String curso) {
        this.curso = curso;
    }

    // Método utilizado para atualizar interesses.
    public void setInteresses(List<String> interesses) {
        this.interesses = interesses == null ? new ArrayList<>() : new ArrayList<>(interesses);
    }

    // Método utilizado para atualizar caminho da foto de perfil.
    public void setFotoPerfilPath(String fotoPerfilPath) {
        this.fotoPerfilPath = fotoPerfilPath;
    }
}
