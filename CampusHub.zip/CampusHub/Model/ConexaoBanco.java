// Define o pacote Model, que organiza as classes do projeto.
package Model;

// Importa as classes e bibliotecas utilizadas neste arquivo.
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

// Classe que representa os dados e características de conexao banco.
public class ConexaoBanco {
    // Atributos
    private static final String URL = "jdbc:sqlite:campushub.db";

    // Construtor
    private ConexaoBanco() {
    }

    // Método responsável por conectar.
    public static Connection conectar() throws SQLException {
        Connection conexao = DriverManager.getConnection(URL);

        try (Statement stmt = conexao.createStatement()) {
            stmt.execute("PRAGMA foreign_keys = ON;");
            return conexao;
        } catch (SQLException e) {
            conexao.close();
            throw e;
        }
    }
}
