// Define o pacote Model, que organiza as classes do projeto.
package Model;

// Biblioteca
import java.util.UUID;

// Classe que representa os dados e características de campeonato.
public class Campeonato {
    // Atributos
    private final String id;
    // Atributo utilizado para armazenar nome.
    private String nome;
    // Atributo utilizado para armazenar modalidade.
    private String modalidade;
    // Atributo utilizado para armazenar descricao.
    private String descricao;
    // Atributo utilizado para armazenar periodo.
    private String periodo;
    // Atributo utilizado para armazenar status.
    private String status;

    // Construtor
    public Campeonato(String nome, String modalidade, String descricao, String periodo, String status) {
        this.id = UUID.randomUUID().toString();
        this.nome = nome;
        this.modalidade = modalidade;
        this.descricao = descricao;
        this.periodo = periodo;
        this.status = status;
    }

    // Métodos Getters
    public String getId() {
        return id;
    }

    // Método utilizado para consultar nome.
    public String getNome() {
        return nome;
    }

    // Método utilizado para consultar modalidade.
    public String getModalidade() {
        return modalidade;
    }

    // Método utilizado para consultar descricao.
    public String getDescricao() {
        return descricao;
    }

    // Método utilizado para consultar periodo.
    public String getPeriodo() {
        return periodo;
    }

    // Método utilizado para consultar status.
    public String getStatus() {
        return status;
    }

    // Métodos Setters
    public void setNome(String nome) {
        this.nome = nome;
    }

    // Método utilizado para atualizar modalidade.
    public void setModalidade(String modalidade) {
        this.modalidade = modalidade;
    }

    // Método utilizado para atualizar descricao.
    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    // Método utilizado para atualizar periodo.
    public void setPeriodo(String periodo) {
        this.periodo = periodo;
    }

    // Método utilizado para atualizar status.
    public void setStatus(String status) {
        this.status = status;
    }
}
