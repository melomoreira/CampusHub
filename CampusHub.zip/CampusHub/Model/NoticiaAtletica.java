// Define o pacote Model, que organiza as classes do projeto.
package Model;

// Biblioteca
import java.util.UUID;

// Classe que representa os dados e características de notícia da atlética.
public class NoticiaAtletica {
    // Atributos
    private final String id;
    // Atributo utilizado para armazenar titulo.
    private String titulo;
    // Atributo utilizado para armazenar categoria.
    private String categoria;
    // Atributo utilizado para armazenar conteudo.
    private String conteudo;
    // Atributo utilizado para armazenar data.
    private String data;
    // Atributo utilizado para armazenar autor.
    private String autor;

    // Construtor
    public NoticiaAtletica(String titulo, String categoria, String conteudo, String data, String autor) {
        this.id = UUID.randomUUID().toString();
        this.titulo = titulo;
        this.categoria = categoria;
        this.conteudo = conteudo;
        this.data = data;
        this.autor = autor;
    }

    // Métodos Getters
    public String getId() {
        return id;
    }

    // Método utilizado para consultar titulo.
    public String getTitulo() {
        return titulo;
    }

    // Método utilizado para consultar categoria.
    public String getCategoria() {
        return categoria;
    }

    // Método utilizado para consultar conteudo.
    public String getConteudo() {
        return conteudo;
    }

    // Método utilizado para consultar data.
    public String getData() {
        return data;
    }

    // Método utilizado para consultar autor.
    public String getAutor() {
        return autor;
    }

    // Métodos Setters
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    // Método utilizado para atualizar categoria.
    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    // Método utilizado para atualizar conteudo.
    public void setConteudo(String conteudo) {
        this.conteudo = conteudo;
    }

    // Método utilizado para atualizar data.
    public void setData(String data) {
        this.data = data;
    }

    // Método utilizado para atualizar autor.
    public void setAutor(String autor) {
        this.autor = autor;
    }
}
