// Define o pacote Model, que organiza as classes do projeto.
package Model;

// Importa as classes e bibliotecas utilizadas neste arquivo.
import java.time.LocalDateTime;
import java.util.UUID;

// Classe que representa os dados e características de material de estudo.
public class MaterialEstudo {
    public enum Tipo {
        RESUMO,
        LISTA_EXERCICIOS,
        APOSTILA,
        SLIDES,
        VIDEO_AULA,
        ARTIGO,
        LIVRO,
        OUTRO
    }

    // Atributos
    private final String id;
    // Atributo utilizado para armazenar autor email.
    private final String autorEmail;
    // Atributo utilizado para armazenar autor nome.
    private final String autorNome;
    // Atributo utilizado para armazenar data criacao.
    private final LocalDateTime dataCriacao;

    // Atributo utilizado para armazenar titulo.
    private String titulo;
    // Atributo utilizado para armazenar descricao.
    private String descricao;
    // Atributo utilizado para armazenar disciplina.
    private String disciplina;
    // Atributo utilizado para armazenar tipo.
    private Tipo tipo;
    // Atributo utilizado para armazenar link.
    private String link;
    // Atributo utilizado para armazenar data atualizacao.
    private LocalDateTime dataAtualizacao;

    // Construtor
    public MaterialEstudo(String autorEmail, String autorNome, String titulo, String descricao, String disciplina, Tipo tipo, String link) {
        this.id = UUID.randomUUID().toString();
        this.autorEmail = autorEmail;
        this.autorNome = autorNome;
        this.dataCriacao = LocalDateTime.now();
        this.dataAtualizacao = this.dataCriacao;

        atualizarDados(titulo, descricao, disciplina, tipo, link);
    }

    // Método utilizado para atualizar atualizar dados.
    public void atualizarDados(String titulo, String descricao, String disciplina, Tipo tipo, String link) {
        this.titulo = titulo;
        this.descricao = descricao;
        this.disciplina = disciplina;
        this.tipo = tipo;
        this.link = link;
        this.dataAtualizacao = LocalDateTime.now();
    }

    // Métodos Getters
    public String getId() {
        return id;
    }

    // Método utilizado para consultar autor email.
    public String getAutorEmail() {
        return autorEmail;
    }

    // Método utilizado para consultar autor nome.
    public String getAutorNome() {
        return autorNome;
    }

    // Método utilizado para consultar data criacao.
    public LocalDateTime getDataCriacao() {
        return dataCriacao;
    }

    // Método utilizado para consultar data atualizacao.
    public LocalDateTime getDataAtualizacao() {
        return dataAtualizacao;
    }

    // Método utilizado para consultar titulo.
    public String getTitulo() {
        return titulo;
    }

    // Método utilizado para consultar descricao.
    public String getDescricao() {
        return descricao;
    }

    // Método utilizado para consultar disciplina.
    public String getDisciplina() {
        return disciplina;
    }

    // Método utilizado para consultar tipo.
    public Tipo getTipo() {
        return tipo;
    }

    // Método utilizado para consultar link.
    public String getLink() {
        return link;
    }
}
