// Define o pacote Model, que organiza as classes do projeto.
package Model;

// Importa as classes e bibliotecas utilizadas neste arquivo.
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

// Classe que representa os dados e características de banco dados.
public class BancoDados {
    // Método responsável por inicializar.
    public static void inicializar() {
        String sqlPublicacao = """
            CREATE TABLE IF NOT EXISTS publicacao (
                id TEXT PRIMARY KEY,
                autor_email TEXT NOT NULL,
                autor_nome TEXT NOT NULL,
                titulo TEXT NOT NULL,
                conteudo TEXT NOT NULL,
                data_criacao TEXT NOT NULL,
                data_atualizacao TEXT NOT NULL
            );""";

        String sqlUsuario = """
            CREATE TABLE IF NOT EXISTS usuario (
                email TEXT PRIMARY KEY COLLATE NOCASE,
                nome TEXT NOT NULL,
                senha_hash TEXT NOT NULL,
                senha_salt TEXT NOT NULL,
                universidade TEXT,
                curso TEXT,
                foto_perfil_path TEXT
            );""";

        String sqlUsuarioInteresse = """
            CREATE TABLE IF NOT EXISTS usuario_interesse (
                usuario_email TEXT NOT NULL,
                interesse TEXT NOT NULL,

                PRIMARY KEY (usuario_email, interesse),

                FOREIGN KEY (usuario_email)
                    REFERENCES usuario(email)
                    ON DELETE CASCADE
            );""";

        // Tabela principal de eventos
        String sqlEvento = """
            CREATE TABLE IF NOT EXISTS evento (
                id TEXT PRIMARY KEY,
                titulo TEXT NOT NULL,
                data TEXT NOT NULL,
                horario TEXT NOT NULL,
                local TEXT NOT NULL,
                descricao TEXT,
                organizador_email TEXT,

                FOREIGN KEY (organizador_email)
                    REFERENCES usuario(email)
                    ON DELETE SET NULL
            );""";

        // Relação entre eventos e participantes
        String sqlEventoParticipante = """
            CREATE TABLE IF NOT EXISTS evento_participante (
                evento_id TEXT NOT NULL,
                usuario_email TEXT NOT NULL,

                PRIMARY KEY (evento_id, usuario_email),

                FOREIGN KEY (evento_id)
                    REFERENCES evento(id)
                    ON DELETE CASCADE,

                FOREIGN KEY (usuario_email)
                    REFERENCES usuario(email)
                    ON DELETE CASCADE
            );""";

        // Tabela principal de grupos
        String sqlGrupo = """
            CREATE TABLE IF NOT EXISTS grupo (
                id TEXT PRIMARY KEY,
                nome TEXT NOT NULL,
                descricao TEXT,
                criador_email TEXT,

                FOREIGN KEY (criador_email)
                    REFERENCES usuario(email)
                    ON DELETE SET NULL
            );""";

        // Relação entre grupos e participantes
        String sqlGrupoMembro = """
            CREATE TABLE IF NOT EXISTS grupo_membro (
                grupo_id TEXT NOT NULL,
                usuario_email TEXT NOT NULL,

                PRIMARY KEY (grupo_id, usuario_email),

                FOREIGN KEY (grupo_id)
                    REFERENCES grupo(id)
                    ON DELETE CASCADE,

                FOREIGN KEY (usuario_email)
                    REFERENCES usuario(email)
                    ON DELETE CASCADE
            );""";

        try (Connection conexao = ConexaoBanco.conectar(); Statement stmt = conexao.createStatement()) {
            stmt.execute(sqlPublicacao);
            stmt.execute(sqlUsuario);
            stmt.execute(sqlUsuarioInteresse);
            stmt.execute(sqlEvento);
            stmt.execute(sqlEventoParticipante);

            // Inicialização das tabelas de grupos
            stmt.execute(sqlGrupo);
            stmt.execute(sqlGrupoMembro);

            System.out.println("Banco de dados inicializado.");
        } catch (SQLException e) {
            System.out.println("Erro ao inicializar o banco:");
            e.printStackTrace();
        }
    }
}
