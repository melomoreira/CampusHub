// Define o pacote Model, que organiza as classes do projeto.
package Model;

// Importa as classes e bibliotecas utilizadas neste arquivo.
import java.time.LocalDateTime;
import java.util.UUID;

// Classe que representa os dados e características de monitoria.
public class Monitoria {
    // Atributos
    private final String id;
    // Atributo utilizado para armazenar autor email.
    private final String autorEmail;
    // Atributo utilizado para armazenar autor nome.
    private final String autorNome;
    // Atributo utilizado para armazenar data criacao.
    private final LocalDateTime dataCriacao;

    // Atributo utilizado para armazenar disciplina.
    private String disciplina;
    // Atributo utilizado para armazenar titulo.
    private String titulo;
    // Atributo utilizado para armazenar descricao.
    private String descricao;
    // Atributo utilizado para armazenar modalidade.
    private String modalidade;
    // Atributo utilizado para armazenar local ou link.
    private String localOuLink;
    // Atributo utilizado para armazenar data atualizacao.
    private LocalDateTime dataAtualizacao;

    // Construtor
    public Monitoria(String autorEmail, String autorNome, String disciplina, String titulo, String descricao, String modalidade, String localOuLink) {
        this.id = UUID.randomUUID().toString();
        this.autorEmail = autorEmail;
        this.autorNome = autorNome;
        this.disciplina = disciplina;
        this.titulo = titulo;
        this.descricao = descricao;
        this.modalidade = modalidade;
        this.localOuLink = localOuLink;
        this.dataCriacao = LocalDateTime.now();
        this.dataAtualizacao = dataCriacao;
    }

    // Métodos Getters
    public String getId() {
        return id;
    }

    // Método utilizado para consultar autor email.
    public String getAutorEmail() {
        return autorEmail;
    }

    // Método utilizado para consultar autor nome.
    public String getAutorNome() {
        return autorNome;
    }

    // Método utilizado para consultar disciplina.
    public String getDisciplina() {
        return disciplina;
    }

    // Método utilizado para consultar titulo.
    public String getTitulo() {
        return titulo;
    }

    // Método utilizado para consultar descricao.
    public String getDescricao() {
        return descricao;
    }

    // Método utilizado para consultar modalidade.
    public String getModalidade() {
        return modalidade;
    }

    // Método utilizado para consultar local ou link.
    public String getLocalOuLink() {
        return localOuLink;
    }

    // Método utilizado para consultar data criacao.
    public LocalDateTime getDataCriacao() {
        return dataCriacao;
    }

    // Método utilizado para consultar data atualizacao.
    public LocalDateTime getDataAtualizacao() {
        return dataAtualizacao;
    }

    // Métodos Setters
    public void setDisciplina(String disciplina) {
        this.disciplina = disciplina;
        this.dataAtualizacao = LocalDateTime.now();
    }

    // Método utilizado para atualizar titulo.
    public void setTitulo(String titulo) {
        this.titulo = titulo;
        this.dataAtualizacao = LocalDateTime.now();
    }

    // Método utilizado para atualizar descricao.
    public void setDescricao(String descricao) {
        this.descricao = descricao;
        this.dataAtualizacao = LocalDateTime.now();
    }

    // Método utilizado para atualizar modalidade.
    public void setModalidade(String modalidade) {
        this.modalidade = modalidade;
        this.dataAtualizacao = LocalDateTime.now();
    }

    // Método utilizado para atualizar local ou link.
    public void setLocalOuLink(String localOuLink) {
        this.localOuLink = localOuLink;
        this.dataAtualizacao = LocalDateTime.now();
    }
}
