// Define o pacote Model, que organiza as classes do projeto.
package Model;

// Importa as classes e bibliotecas utilizadas neste arquivo.
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

// Classe responsável pelo acesso aos dados de grupo.
public class GrupoDAO {
    // Atributos
    private final UsuarioDAO usuarioDAO = new UsuarioDAO();

    // =========================
    // SALVAR GRUPO
    // =========================

    // Método responsável por salvar.
    public boolean salvar(Grupo grupo) {
        String sqlGrupo = """
            INSERT INTO grupo (id, nome, descricao, criador_email)
            VALUES (?, ?, ?, ?);""";

        String sqlMembro = """
            INSERT INTO grupo_membro (grupo_id, usuario_email)
            VALUES (?, ?);""";

        try (Connection conexao = ConexaoBanco.conectar()) {
            conexao.setAutoCommit(false);

            try (PreparedStatement stmtGrupo = conexao.prepareStatement(sqlGrupo)) {
                stmtGrupo.setString(1, grupo.getId());
                stmtGrupo.setString(2, grupo.getNome());
                stmtGrupo.setString(3, grupo.getDescricao());

                if (grupo.getCriador() != null) {
                    stmtGrupo.setString(4, grupo.getCriador().getEmail());
                } else {
                    stmtGrupo.setNull(4, java.sql.Types.VARCHAR);
                }

                stmtGrupo.executeUpdate();
            }

            try (PreparedStatement stmtMembro = conexao.prepareStatement(sqlMembro)) {
                for (Usuario participante : grupo.getParticipantes()) {
                    if (participante != null && participante.getEmail() != null) {
                        stmtMembro.setString(1, grupo.getId());
                        stmtMembro.setString(2, participante.getEmail());
                        stmtMembro.addBatch();
                    }
                }

                stmtMembro.executeBatch();
            }

            conexao.commit();
            return true;
        } catch (SQLException e) {
            System.out.println("Erro ao salvar grupo:");
            e.printStackTrace();
            return false;
        }
    }

    // =========================
    // LISTAR GRUPOS
    // =========================

    // Método utilizado para consultar listar todos.
    public ArrayList<Grupo> listarTodos() {
        ArrayList<Grupo> grupos = new ArrayList<>();

        String sql = """
            SELECT id, nome, descricao, criador_email
            FROM grupo
            ORDER BY nome COLLATE NOCASE;""";

        try (Connection conexao = ConexaoBanco.conectar(); PreparedStatement stmt = conexao.prepareStatement(sql); ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Grupo grupo = mapearGrupo(rs);
                grupos.add(grupo);
            }
        } catch (SQLException e) {
            System.out.println("Erro ao listar grupos:");
            e.printStackTrace();
        }

        return grupos;
    }

    // =========================
    // BUSCAR GRUPO POR ID
    // =========================

    // Método utilizado para consultar buscar por id.
    public Grupo buscarPorId(String id) {
        String sql = """
            SELECT id, nome, descricao, criador_email
            FROM grupo
            WHERE id = ?;""";

        try (Connection conexao = ConexaoBanco.conectar(); PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setString(1, id);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapearGrupo(rs);
                }
            }
        } catch (SQLException e) {
            System.out.println("Erro ao buscar grupo:");
            e.printStackTrace();
        }

        return null;
    }

    // =========================
    // ATUALIZAR GRUPO
    // =========================

    // Método utilizado para atualizar atualizar.
    public boolean atualizar(Grupo grupo) {
        String sql = """
            UPDATE grupo
            SET nome = ?, descricao = ?
            WHERE id = ?;""";

        try (Connection conexao = ConexaoBanco.conectar(); PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setString(1, grupo.getNome());
            stmt.setString(2, grupo.getDescricao());
            stmt.setString(3, grupo.getId());

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Erro ao atualizar grupo:");
            e.printStackTrace();
            return false;
        }
    }

    // =========================
    // EXCLUIR GRUPO
    // =========================

    // Método utilizado para remover excluir.
    public boolean excluir(String id) {
        String sql = "DELETE FROM grupo WHERE id = ?;";

        try (Connection conexao = ConexaoBanco.conectar(); PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setString(1, id);

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Erro ao excluir grupo:");
            e.printStackTrace();
            return false;
        }
    }

    // =========================
    // PARTICIPAR DE GRUPO
    // =========================

    // Método responsável por participar.
    public boolean participar(String grupoId, Usuario usuario) {
        if (usuario == null || usuario.getEmail() == null) {
            return false;
        }

        String sql = """
            INSERT INTO grupo_membro (grupo_id, usuario_email)
            VALUES (?, ?);""";

        try (Connection conexao = ConexaoBanco.conectar(); PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setString(1, grupoId);
            stmt.setString(2, usuario.getEmail());

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            // Pode ocorrer se o usuário já estiver participando
            return false;
        }
    }

    // =========================
    // SAIR DE GRUPO
    // =========================

    // Método responsável por sair.
    public boolean sair(String grupoId, Usuario usuario) {
        if (usuario == null || usuario.getEmail() == null) {
            return false;
        }

        String sql = """
            DELETE FROM grupo_membro
            WHERE grupo_id = ?
              AND usuario_email = ?;""";

        try (Connection conexao = ConexaoBanco.conectar(); PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setString(1, grupoId);
            stmt.setString(2, usuario.getEmail());

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Erro ao sair do grupo:");
            e.printStackTrace();
            return false;
        }
    }

    // =========================
    // VERIFICAR PARTICIPAÇÃO
    // =========================

    // Método responsável por usuario participa.
    public boolean usuarioParticipa(String grupoId, Usuario usuario) {
        if (usuario == null || usuario.getEmail() == null) {
            return false;
        }

        String sql = """
            SELECT 1
            FROM grupo_membro
            WHERE grupo_id = ?
              AND usuario_email = ?
            LIMIT 1;""";

        try (Connection conexao = ConexaoBanco.conectar(); PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setString(1, grupoId);
            stmt.setString(2, usuario.getEmail());

            try (ResultSet rs = stmt.executeQuery()) {
                return rs.next();
            }
        } catch (SQLException e) {
            System.out.println("Erro ao verificar participação:");
            e.printStackTrace();
            return false;
        }
    }

    // =========================
    // MAPEAR GRUPO DO BANCO
    // =========================

    // Método responsável por mapear grupo.
    private Grupo mapearGrupo(ResultSet rs) throws SQLException {
        String id = rs.getString("id");
        String nome = rs.getString("nome");
        String descricao = rs.getString("descricao");
        String criadorEmail = rs.getString("criador_email");

        Usuario criador = null;

        if (criadorEmail != null) {
            criador = usuarioDAO.buscarPorEmail(criadorEmail);
        }

        Grupo grupo = new Grupo(id, nome, descricao, criador);

        carregarParticipantes(grupo);

        return grupo;
    }

    // =========================
    // CARREGAR PARTICIPANTES
    // =========================

    // Método responsável por carregar participantes.
    private void carregarParticipantes(Grupo grupo) {
        String sql = """
            SELECT usuario_email
            FROM grupo_membro
            WHERE grupo_id = ?;""";

        try (Connection conexao = ConexaoBanco.conectar(); PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setString(1, grupo.getId());

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    String email = rs.getString("usuario_email");

                    Usuario usuario = usuarioDAO.buscarPorEmail(email);

                    if (usuario != null) {
                        grupo.adicionarParticipante(usuario);
                    }
                }
            }
        } catch (SQLException e) {
            System.out.println("Erro ao carregar participantes:");
            e.printStackTrace();
        }
    }
}
