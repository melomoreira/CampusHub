// Define o pacote Model, que organiza as classes do projeto.
package Model;

// Biblioteca
import java.util.UUID;

// Classe que representa os dados e características de equipe.
public class Equipe {
    // Atributos
    private final String id;
    // Atributo utilizado para armazenar nome.
    private String nome;
    // Atributo utilizado para armazenar modalidade.
    private String modalidade;
    // Atributo utilizado para armazenar descricao.
    private String descricao;
    // Atributo utilizado para armazenar possui seletiva.
    private boolean possuiSeletiva;
    // Atributo utilizado para armazenar informacao seletiva.
    private String informacaoSeletiva;

    // Construtor
    public Equipe(String nome, String modalidade, String descricao, boolean possuiSeletiva, String informacaoSeletiva) {
        this.id = UUID.randomUUID().toString();
        this.nome = nome;
        this.modalidade = modalidade;
        this.descricao = descricao;
        this.possuiSeletiva = possuiSeletiva;
        this.informacaoSeletiva = informacaoSeletiva;
    }

    // Métodos Getters
    public String getId() {
        return id;
    }

    // Método utilizado para consultar nome.
    public String getNome() {
        return nome;
    }

    // Método utilizado para consultar modalidade.
    public String getModalidade() {
        return modalidade;
    }

    // Método utilizado para consultar descricao.
    public String getDescricao() {
        return descricao;
    }

    // Método utilizado para verificar possui seletiva.
    public boolean isPossuiSeletiva() {
        return possuiSeletiva;
    }

    // Método utilizado para consultar informacao seletiva.
    public String getInformacaoSeletiva() {
        return informacaoSeletiva;
    }

    // Métodos Setters
    public void setNome(String nome) {
        this.nome = nome;
    }

    // Método utilizado para atualizar modalidade.
    public void setModalidade(String modalidade) {
        this.modalidade = modalidade;
    }

    // Método utilizado para atualizar descricao.
    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    // Método utilizado para atualizar possui seletiva.
    public void setPossuiSeletiva(boolean possuiSeletiva) {
        this.possuiSeletiva = possuiSeletiva;
    }

    // Método utilizado para atualizar informacao seletiva.
    public void setInformacaoSeletiva(String informacaoSeletiva) {
        this.informacaoSeletiva = informacaoSeletiva;
    }
}
