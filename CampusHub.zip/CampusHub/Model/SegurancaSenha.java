// Define o pacote Model, que organiza as classes do projeto.
package Model;

// Importa as classes e bibliotecas utilizadas neste arquivo.
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.security.spec.KeySpec;
import java.util.Base64;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

// Classe que representa os dados e características de seguranca senha.
public class SegurancaSenha {
    // Atributos
    private static final int ITERACOES = 210000;
    // Atributo utilizado para armazenar tamanho salt.
    private static final int TAMANHO_SALT = 16;
    // Atributo utilizado para armazenar tamanho hash.
    private static final int TAMANHO_HASH = 256;

    private static final SecureRandom RANDOM = new SecureRandom();

    // Construtor
    private SegurancaSenha() {
    }

    // Método responsável por gerar salt.
    public static String gerarSalt() {
        byte[] salt = new byte[TAMANHO_SALT];
        RANDOM.nextBytes(salt);

        return Base64.getEncoder().encodeToString(salt);
    }

    // Método responsável por gerar hash.
    public static String gerarHash(String senha, String saltBase64) {
        if (senha == null || saltBase64 == null) {
            throw new IllegalArgumentException("Senha e salt são obrigatórios.");
        }

        byte[] salt = Base64.getDecoder().decode(saltBase64);
        char[] senhaCaracteres = senha.toCharArray();

        PBEKeySpec spec = new PBEKeySpec(senhaCaracteres, salt, ITERACOES, TAMANHO_HASH);

        try {
            SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");

            byte[] hash = factory.generateSecret(spec).getEncoded();

            return Base64.getEncoder().encodeToString(hash);
        } catch (Exception e) {
            throw new IllegalStateException("Erro ao gerar hash da senha.", e);
        } finally {
            spec.clearPassword();
            java.util.Arrays.fill(senhaCaracteres, '\0');
        }
    }

    // Método utilizado para verificar verificar senha.
    public static boolean verificarSenha(String senhaInformada, String hashArmazenado, String saltArmazenado) {
        if (senhaInformada == null || hashArmazenado == null || saltArmazenado == null) {
            return false;
        }

        String hashCalculado = gerarHash(senhaInformada, saltArmazenado);

        byte[] hash1 = Base64.getDecoder().decode(hashCalculado);
        byte[] hash2 = Base64.getDecoder().decode(hashArmazenado);

        return MessageDigest.isEqual(hash1, hash2);
    }
}
