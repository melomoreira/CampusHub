// Define o pacote Model, que organiza as classes do projeto.
package Model;

// Classe que representa os dados e características de atividade acadêmica.
public class AtividadeAcademica {
    // Atributos da atividade
    private String tipo;
    // Atributo utilizado para armazenar descricao.
    private String descricao;

    // Construtor com as informações da atividade
    public AtividadeAcademica(String tipo, String descricao) {
        this.tipo = tipo;
        this.descricao = descricao;
    }

    // Métodos getters: utilizados para consultar os atributos
    public String getTipo() {
        return tipo;
    }

    // Método utilizado para consultar descricao.
    public String getDescricao() {
        return descricao;
    }

    // Métodos setters: utilizados para modificar os atributos
    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    // Método utilizado para atualizar descricao.
    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
}
