// Define o pacote Model, que organiza as classes do projeto.
package Model;

// Classe que representa os dados e características de missão.
public class Missao {
    // Identificação da missão e seus relacionamentos
    private String id;
    // Atributo utilizado para armazenar campus id.
    private String campusId;
    // Atributo utilizado para armazenar ponto interesse id.
    private String pontoInteresseId;

    // Informações da missão
    private String titulo;
    // Atributo utilizado para armazenar descricao.
    private String descricao;
    // Atributo utilizado para armazenar recompensa.
    private int recompensa;

    // Construtor com todas as informações da missão
    public Missao(String id, String campusId, String pontoInteresseId, String titulo, String descricao, int recompensa) {
        this.id = id;
        this.campusId = campusId;
        this.pontoInteresseId = pontoInteresseId;
        this.titulo = titulo;
        this.descricao = descricao;
        this.recompensa = recompensa;
    }

    // Métodos getters: utilizados para consultar os atributos
    public String getId() {
        return id;
    }

    // Método utilizado para consultar campus id.
    public String getCampusId() {
        return campusId;
    }

    // Método utilizado para consultar ponto interesse id.
    public String getPontoInteresseId() {
        return pontoInteresseId;
    }

    // Método utilizado para consultar titulo.
    public String getTitulo() {
        return titulo;
    }

    // Método utilizado para consultar descricao.
    public String getDescricao() {
        return descricao;
    }

    // Método utilizado para consultar recompensa.
    public int getRecompensa() {
        return recompensa;
    }

    // Métodos setters: utilizados para modificar os atributos
    public void setId(String id) {
        this.id = id;
    }

    // Método utilizado para atualizar campus id.
    public void setCampusId(String campusId) {
        this.campusId = campusId;
    }

    // Método utilizado para atualizar ponto interesse id.
    public void setPontoInteresseId(String pontoInteresseId) {
        this.pontoInteresseId = pontoInteresseId;
    }

    // Método utilizado para atualizar titulo.
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    // Método utilizado para atualizar descricao.
    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    // Método utilizado para atualizar recompensa.
    public void setRecompensa(int recompensa) {
        this.recompensa = recompensa;
    }
}
