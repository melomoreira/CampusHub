// Define o pacote Model, que organiza as classes do projeto.
package Model;

// Importa as classes e bibliotecas utilizadas neste arquivo.
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

// Classe que representa os dados e características de grupo.
public class Grupo {
    // Identificador único do grupo
    private final String id;

    // Informações do grupo
    private String nome;
    // Atributo utilizado para armazenar descricao.
    private String descricao;

    // Criador e lista de participantes
    private final Usuario criador;
    // Atributo utilizado para armazenar participantes.
    private final List<Usuario> participantes;

    // Construtor com nome e descrição
    public Grupo(String nome, String descricao) {
        this(nome, descricao, null);
    }

    // Construtor com nome, descrição e criador
    public Grupo(String nome, String descricao, Usuario criador) {
        this.id = UUID.randomUUID().toString();
        this.nome = nome;
        this.descricao = descricao;
        this.criador = criador;
        this.participantes = new ArrayList<>();
    }

    // Construtor para reconstruir grupo com ID existente do banco
    public Grupo(String id, String nome, String descricao, Usuario criador) {
        this.id = id;
        this.nome = nome;
        this.descricao = descricao;
        this.criador = criador;
        this.participantes = new ArrayList<>();
    }

    // Métodos getters: utilizados para consultar os atributos
    public String getId() {
        return id;
    }

    // Método utilizado para consultar nome.
    public String getNome() {
        return nome;
    }

    // Método utilizado para consultar descricao.
    public String getDescricao() {
        return descricao;
    }

    // Método utilizado para consultar criador.
    public Usuario getCriador() {
        return criador;
    }

    // Método utilizado para consultar participantes.
    public List<Usuario> getParticipantes() {
        return participantes;
    }

    // Métodos setters: utilizados para modificar os atributos
    public void setNome(String nome) {
        this.nome = nome;
    }

    // Método utilizado para atualizar descricao.
    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    // Métodos para gerenciar os participantes do grupo
    public void adicionarParticipante(Usuario usuario) {
        if (usuario != null && !participantes.contains(usuario)) {
            participantes.add(usuario);
        }
    }

    // Método utilizado para remover remover participante.
    public void removerParticipante(Usuario usuario) {
        participantes.remove(usuario);
    }
}
