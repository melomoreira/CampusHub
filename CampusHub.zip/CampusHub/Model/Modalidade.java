// Define o pacote Model, que organiza as classes do projeto.
package Model;

// Biblioteca
import java.util.UUID;

// Classe que representa os dados e características de modalidade.
public class Modalidade {
    // Atributos
    private final String id;
    // Atributo utilizado para armazenar nome.
    private String nome;
    // Atributo utilizado para armazenar categoria.
    private String categoria;
    // Atributo utilizado para armazenar descricao.
    private String descricao;

    // Construtor
    public Modalidade(String nome, String categoria, String descricao) {
        this.id = UUID.randomUUID().toString();
        this.nome = nome;
        this.categoria = categoria;
        this.descricao = descricao;
    }

    // Métodos Getters
    public String getId() {
        return id;
    }

    // Método utilizado para consultar nome.
    public String getNome() {
        return nome;
    }

    // Método utilizado para consultar categoria.
    public String getCategoria() {
        return categoria;
    }

    // Método utilizado para consultar descricao.
    public String getDescricao() {
        return descricao;
    }

    // Métodos Setters
    public void setNome(String nome) {
        this.nome = nome;
    }

    // Método utilizado para atualizar categoria.
    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    // Método utilizado para atualizar descricao.
    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
}
