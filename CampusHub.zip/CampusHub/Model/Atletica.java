// Define o pacote Model, que organiza as classes do projeto.
package Model;

// Classe que representa os dados e características de atlética.
public class Atletica {
    // Atributos da atlética
    private String nome;
    // Atributo utilizado para armazenar descricao.
    private String descricao;

    // Construtor com as informações da atlética
    public Atletica(String nome, String descricao) {
        this.nome = nome;
        this.descricao = descricao;
    }

    // Métodos getters: utilizados para consultar os atributos
    public String getNome() {
        return nome;
    }

    // Método utilizado para consultar descricao.
    public String getDescricao() {
        return descricao;
    }

    // Métodos setters: utilizados para modificar os atributos
    public void setNome(String nome) {
        this.nome = nome;
    }

    // Método utilizado para atualizar descricao.
    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
}
