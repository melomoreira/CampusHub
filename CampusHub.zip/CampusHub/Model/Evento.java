// Define o pacote Model, que organiza as classes do projeto.
package Model;

// Importa as classes e bibliotecas utilizadas neste arquivo.
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

// Classe que representa os dados e características de evento.
public class Evento {
    // Atributos do evento
    private final String id;
    // Atributo utilizado para armazenar titulo.
    private String titulo;
    // Atributo utilizado para armazenar data.
    private String data;
    // Atributo utilizado para armazenar horario.
    private String horario;
    // Atributo utilizado para armazenar local.
    private String local;
    // Atributo utilizado para armazenar descricao.
    private String descricao;
    // Atributo utilizado para armazenar organizador.
    private Usuario organizador;
    // Atributo utilizado para armazenar participantes.
    private List<Usuario> participantes;

    // Construtor com informações básicas do evento
    public Evento(String data, String horario, String local, String descricao) {
        this("Evento", data, horario, local, descricao, null);
    }

    // Construtores com todas as informações do evento
    public Evento(String titulo, String data, String horario, String local, String descricao, Usuario organizador) {
        this.id = UUID.randomUUID().toString();
        this.titulo = titulo;
        this.data = data;
        this.horario = horario;
        this.local = local;
        this.descricao = descricao;
        this.organizador = organizador;
        this.participantes = new ArrayList<>();
    }

    // Método responsável por evento.
    public Evento(String id, String titulo, String data, String horario, String local, String descricao, Usuario organizador) {
        this.id = id;
        this.titulo = titulo;
        this.data = data;
        this.horario = horario;
        this.local = local;
        this.descricao = descricao;
        this.organizador = organizador;
        this.participantes = new ArrayList<>();
    }

    // Métodos getters: utilizados para consultar os atributos
    public String getId() {
        return id;
    }

    // Método utilizado para consultar titulo.
    public String getTitulo() {
        return titulo;
    }

    // Método utilizado para consultar data.
    public String getData() {
        return data;
    }

    // Método utilizado para consultar horario.
    public String getHorario() {
        return horario;
    }

    // Método utilizado para consultar local.
    public String getLocal() {
        return local;
    }

    // Método utilizado para consultar descricao.
    public String getDescricao() {
        return descricao;
    }

    // Método utilizado para consultar organizador.
    public Usuario getOrganizador() {
        return organizador;
    }

    // Método utilizado para consultar participantes.
    public List<Usuario> getParticipantes() {
        return participantes;
    }

    // Métodos setters: utilizados para modificar os atributos
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    // Método utilizado para atualizar data.
    public void setData(String data) {
        this.data = data;
    }

    // Método utilizado para atualizar horario.
    public void setHorario(String horario) {
        this.horario = horario;
    }

    // Método utilizado para atualizar local.
    public void setLocal(String local) {
        this.local = local;
    }

    // Método utilizado para atualizar descricao.
    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    // Método utilizado para atualizar organizador.
    public void setOrganizador(Usuario organizador) {
        this.organizador = organizador;
    }

    // Métodos para gerenciar os participantes do evento
    public void adicionarParticipante(Usuario usuario) {
        if (usuario != null && !participantes.contains(usuario)) {
            participantes.add(usuario);
        }
    }

    // Método utilizado para remover remover participante.
    public void removerParticipante(Usuario usuario) {
        participantes.remove(usuario);
    }
}
