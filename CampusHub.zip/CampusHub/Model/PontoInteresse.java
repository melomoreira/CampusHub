// Define o pacote Model, que organiza as classes do projeto.
package Model;

// Classe que representa os dados e características de ponto interesse.
public class PontoInteresse {
    // Identificação do ponto de interesse
    private String id;
    // Atributo utilizado para armazenar campus id.
    private String campusId;

    // Informações do local
    private String nome;
    // Atributo utilizado para armazenar descricao.
    private String descricao;
    // Atributo utilizado para armazenar categoria.
    private String categoria;
    // Atributo utilizado para armazenar icone.
    private String icone;

    // Posição do marcador no mapa (valores de 0.0 a 1.0)
    private double posX;
    // Atributo utilizado para armazenar pos y.
    private double posY;

    // Construtor com todas as informações do ponto de interesse
    public PontoInteresse(String id, String campusId, String nome, String descricao, String categoria, String icone, double posX, double posY) {
        this.id = id;
        this.campusId = campusId;
        this.nome = nome;
        this.descricao = descricao;
        this.categoria = categoria;
        this.icone = icone;
        this.posX = posX;
        this.posY = posY;
    }

    // Métodos getters: utilizados para consultar os atributos
    public String getId() {
        return id;
    }

    // Método utilizado para consultar campus id.
    public String getCampusId() {
        return campusId;
    }

    // Método utilizado para consultar nome.
    public String getNome() {
        return nome;
    }

    // Método utilizado para consultar descricao.
    public String getDescricao() {
        return descricao;
    }

    // Método utilizado para consultar categoria.
    public String getCategoria() {
        return categoria;
    }

    // Método utilizado para consultar icone.
    public String getIcone() {
        return icone;
    }

    // Método utilizado para consultar pos x.
    public double getPosX() {
        return posX;
    }

    // Método utilizado para consultar pos y.
    public double getPosY() {
        return posY;
    }

    // Métodos setters: utilizados para modificar os atributos
    public void setId(String id) {
        this.id = id;
    }

    // Método utilizado para atualizar campus id.
    public void setCampusId(String campusId) {
        this.campusId = campusId;
    }

    // Método utilizado para atualizar nome.
    public void setNome(String nome) {
        this.nome = nome;
    }

    // Método utilizado para atualizar descricao.
    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    // Método utilizado para atualizar categoria.
    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    // Método utilizado para atualizar icone.
    public void setIcone(String icone) {
        this.icone = icone;
    }

    // Método utilizado para atualizar pos x.
    public void setPosX(double posX) {
        this.posX = posX;
    }

    // Método utilizado para atualizar pos y.
    public void setPosY(double posY) {
        this.posY = posY;
    }
}
